// TODO
// position selection should be on basis of file on disk, not of eval itself - otherwise, 
// when you run the optimizer again, it gives a different result because the eval has changed.

#include <stdlib.h> 
#include <assert.h>
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <process.h>




#include "stdafx.h"

// cake-specific includes - structs defines structures, consts defines constants,
// xxx.h defines function prototypes for xxx.c
#include "../optimizeCake.h"  // important to load first!
#include "..\\switches.h"
#include "structs.h"
#include "consts.h"
#include "..\\cake_eval.h"
#include "..\\egdb.h"


#ifdef USE_KR_DB
EGDB_DRIVER* handle;
char* out = 0;
#endif

#define SKIP 0 // 4000000

#define WHITE 1
#define BLACK 2
#define MAN 4
#define KING 8
#define FREE 16

#define MAXINDEX 531441



/*#define PARAMS 408
#ifdef BRTHREE
#define PARAMS 4248
#endif*/


//#undef WEIGHT_BY_NUMBER
//#undef WEIGHT_BY_EQUAL
//#define AVERAGE  // use the average version of the data


/* bitboard masks for moves in various directions */
/* here "1" means the squares in the columns 1357 and "2" in 2468.*/
#define RF1  0x0F0F0F0F
#define RF2  0x00707070
#define LF1  0x0E0E0E0E
#define LF2  0x00F0F0F0
#define RB1  0x0F0F0F00
#define RB2  0x70707070
#define LB1  0x0E0E0E00
#define LB2  0xF0F0F0F0
/* bitboard masks for jumps in various directions */
#define RFJ1  0x00070707
#define RFJ2  0x00707070
#define LFJ1  0x000E0E0E
#define LFJ2  0x00E0E0E0
#define RBJ1  0x07070700
#define RBJ2  0x70707000
#define LBJ1  0x0E0E0E00
#define LBJ2  0xE0E0E000

/* back rank masks */
#define WBR  0xF0000000
#define BBR  0x0000000F
#define NWBR 0x0FFFFFFF
#define NBBR 0xFFFFFFF0

// ranks
#define RANK1 0xF
#define RANK2 0xF0
#define RANK3 0xF00
#define RANK4 0xF000
#define RANK5 0xF0000
#define RANK6 0xF00000
#define RANK7 0xF000000
#define RANK8 0xF0000000

double sigmoid(double v, double c);
void codeoutput(int recall);

int result_translated[4] = { 0, 1, -1, 0 };
static int params[PARAMS]; // parameters to optimize
int index[4096];
int indexnum[MAXINDEX];
char DBpath[256] = "C:\\Programme\\CheckerBoard64\\db";

int active_set[PARAMS]; // specify which parameters are used in optimization.

char strs[PARAMS][128] =  {
	"man_value", "king_value", "piecedown_9", "piecedown_11", "twokingbonus_10", "twokingbonus_12",
	"exchangebias",	"backrankpower1","backrankpower2", "backrankpower3", "backrankpower4", 
	"immobile_mult", "immobile_mult_kings", "ungroundedcontact", "balancemult", "skewnessmult", "skewnessmult_eg",
	"dogholeval2", "dogholeval", "dogholemandownval",
	"mc_occupyval", "mc_attackval", "realdykeval", "greatdykeval",
	"cramp20", "nocrampval20", "cramp13", "cramp13_eg", "nocrampval13", "cramp12",
	"badstructure3", "badstructure4", "badstructure",
	"badstructure2", "badstructure5", "badstructure6", "badstructure7", "badstructure8",
	"badstructure9", "badstructure10", "badstructure11",
	"promoteinone", "runaway_destroys_backrank", "promoteintwo", "promoteinthree",
	"kingtrappedinsinglecornerval", "kingtrappedinsinglecornerbytwoval", "kingtrappedindoublecornerval",
	"king_blocks_king_and_man", "dominatedkingval", "dominatedkingval2", "dominatedkingindcval", "dominatedkingindcval2",
	"king_denied_center", "kingcentermonopoly", "onlykingval", "roamingkingval",
	"experimental_king_cramp", "keval",
	"tailhookval", "kingproximityval1", "kingproximityval2", "endangeredbridge_kingdown", "endangeredbridge",
	"kingholdstwomenval", "immobilemanval", "compensation", "compensation_mandown",
	"turnval", "turnval_eg",
	"edgepressure1", "edgepressure2",


	"ungrounded0", "ungrounded1", "ungrounded2", "ungrounded3", "ungrounded4", "ungrounded5", "ungrounded6", 
	"ungrounded7", "ungrounded8", "ungrounded9", "ungrounded10", "ungrounded11", "ungrounded12",
	
	"br0", "br1", "br2", "br3", "br4", "br5", "br6", "br7",
	"br8", "br9", "br10", "br11", "br12", "br13", "br14", "br15",
	"br16", "br17", "br18", "br19", "br20", "br21", "br22", "br23",
	"br24", "br25", "br26", "br27", "br28", "br29", "br30", "br31",

	"br32", "br33", "br34", "br35", "br36", "br37", "br38", "br39",
	"br40", "br41", "br42", "br43", "br44", "br45", "br46", "br47",
	"br48", "br49", "br50", "br51", "br52", "br53", "br54", "br55",
	"br56", "br57", "br58", "br59", "br60", "br61", "br62", "br63",

	"br64", "br65", "br66", "br67", "br68", "br69", "br70", "br71",
	"br72", "br73", "br74", "br75", "br76", "br77", "br78", "br79",
	"br80", "br81", "br82", "br83", "br84", "br85", "br86", "br87",
	"br88", "br89", "br90", "br91", "br92", "br93", "br94", "br95",

		"br96", "br97", "br98", "br99", "br100", "br101", "br102", "br103",
	"br104", "br105", "br106", "br107", "br108", "br109", "br110", "br111",
	"br112", "br113", "br114", "br115", "br116", "br117", "br118", "br119",
	"br120", "br121", "br122", "br123", "br124", "br125", "br126", "br127",

		"br128", "br129", "br130", "br131", "br132", "br133", "br134", "br135",
	"br136", "br137", "br138", "br139", "br140", "br141", "br142", "br143",
	"br144", "br145", "br146", "br147", "br148", "br149", "br150", "br151",
	"br152", "br153", "br154", "br155", "br156", "br157", "br158", "br159",

		"br160", "br161", "br162", "br163", "br164", "br165", "br166", "br167",
	"br168", "br169", "br170", "br171", "br172", "br173", "br174", "br175",
	"br176", "br177", "br178", "br179", "br180", "br181", "br182", "br183",
	"br184", "br185", "br186", "br187", "br188", "br189", "br190", "br191",

		"br192", "br193", "br194", "br195", "br196", "br197", "br198", "br199",
	"br200", "br201", "br202", "br203", "br204", "br205", "br206", "br207",
	"br208", "br209", "br210", "br211", "br212", "br213", "br214", "br215",
	"br216", "br217", "br218", "br219", "br220", "br221", "br222", "br223",

		"br224", "br225", "br226", "br227", "br228", "br229", "br230", "br231",
	"br232", "br233", "br234", "br235", "br236", "br237", "br238", "br239",
	"br240", "br241", "br242", "br243", "br244", "br245", "br246", "br247",
	"br248", "br249", "br250", "br251", "br252", "br253", "br254", "br255",

	


	"tmod0", "tmod1", "tmod2", "tmod3", "tmod4", "tmod5", "tmod6", "tmod7",
	"tmod8", "tmod9", "tmod10", "tmod11", "tmod12", "tmod13", "tmod14", "tmod15",
	"tmod16", "tmod17", "tmod18", "tmod19", "tmod20", "tmod21", "tmod22", "tmod23", "tmod24",
	"kmob0", "kmob1", "kmob2", "kmob3", "kmob4", "kmob5", "kmob6", "kmob7", "kmob8", "kmob9",
		"kpst0", "kpst1", "kpst2", "kpst3", "kpst4", "kpst5", "kpst6", "kpst7",
		"kpst8", "kpst9", "kpst10", "kpst11", "kpst12", "kpst13", "kpst14", "kpst15",
		"kpst16", "kpst17", "kpst18", "kpst19", "kpst20", "kpst21", "kpst22", "kpst23",
		"kpst24", "kpst25", "kpst26", "kpst27", "kpst28", "kpst29", "kpst30", "kpst31",

};




double calc_error(int n, EVALUATEDPOSITION* ep, double c);
double calc_error_MT(int n, EVALUATEDPOSITION* ep, double c);

double error_ST[30000000];
double error_MT[30000000];

#ifdef STOCHASTIC
short int* isinactive; 
#endif

typedef struct
{
	EVALUATEDPOSITION* ep; 
	int start; 
	int end; 
	double errorsum;
	int threadID; 
	double c;
	int gamenum; 
} THREADINFO;




int main()
{
	int i = 0, n;
	FILE *fp; 
	unsigned int bm, bk, wm, wk, color; 
	POSITION p; 
	MATERIALCOUNT mc; 
	int delta = 100; 
	EVALUATEDPOSITION *ep, *cur; 
	double error;
	int j; 
	int oldparam; 
	int iterations = 0; 
	double minerror;
	int position_number = 0; 
	int changed = 0; 
	int res_from_file; 
	double c;
	int rejected = 0; 
	int rejectednum = 0; 
	int pos_num = 0; 
	int quiet_pos_num = 0; 
	int /*v0, */v1, v3, staticeval; 
	int iter[3] = { 1,0,2 };
	int sameadjust; 
	int adjust; 
	int paramnum = 0; 
	int allactive = 1; 
	int initialparams[PARAMS]; 
	double influence[PARAMS];
	double influence0[PARAMS];
	int wins, draws, losses; 
	int totalgames = 0; 
	int totalpositions = 0; 
	int totalquietpositions = 0; 
	char FEN[256]; 
	FILE* log; 
	double tolerance = 3e-12;		// minimal change in error that a parameter is still changed
	int usedgames = 0 ; 
	int unusedgames = 0; 

	// if I want to check search times, run analyze_matchprogress()
	//analyze_matchprogress(); 

	//calc_error_MT(); 
	//getch(); 

	//create_indices(); 

	ep = malloc(sizeof(EVALUATEDPOSITION) * 30000000);

#ifdef BRTHREE
	// rename parameter strings
	for (i = 0; i < PARAMS; i++)
		if (strcmp(strs[i], "br0") == 0)
			break; 
	printf("\nbr0 found at index %i", i); 
	
	i = i + 256; 
	for (j = i; j < PARAMS - 4096 + 256; j++)
		sprintf(strs[j + 4096 - 256], "%s", strs[j]); 
	for (j = 0; j < 4096; j++)
		sprintf(strs[j + i -256], "br%i", j); 
	//for (i = 0; i < PARAMS; i++)
	//	printf("\n%i %s", i, strs[i]); 
	//getch(); 
	//exit(0); 

#endif

	// initialize eval
	initeval();
	//startparams();
	optimalparams(); 
	updateeval();

	// recall parameters from cake's evaluation
	//startparams(); 
	//optimalparams(); 
	//updateeval
#ifdef ZERO
	zeroparams(); 
	updateeval(); 
#endif
	getparams(params, &paramnum);

	printf("\nPARAMS is %i, paramnum is %i", PARAMS, paramnum);
	// print parameters to show it's working
	for (i = 0; i < paramnum; i++) {
		//printf("\nparameter[%i] is %i (%s)", i, params[i], strs[i]);
		initialparams[i] = params[i]; 
	}
	printf("\nfound %i parameters to optimize", paramnum); 

	// open optimizer logfile, save params
	log = fopen("c:\\code\\checkersdata\\optimizerlog.txt", "w");

	//getch(); 

	// here, test specific positions: rattlesnake problem because of freewk < freebk, check again later
	/*
	sprintf(FEN, "W:W28,K15,13,K11,7:BK25,K22,12,5,4."); 
	FENtoPosition(FEN, &p);
	mc.bm = bitcount(p.bm);
	mc.bk = bitcount(p.bk);
	mc.wm = bitcount(p.wm);
	mc.wk = bitcount(p.wk);
	staticeval = evaluation(&p, &mc, 0, &delta, 0, 0);
	getch(); */

	// load either file with or without duplicates
#ifdef AVERAGE
	fp = fopen("c:\\code\\checkersdata\\taggedevaluatedpositions_av.txt", "r");
#else
#ifdef NODUPLICATES
    fp = fopen("c:\\code\\checkersdata\\taggedevaluatedpositions.txt", "r");
#else
	fp = fopen("c:\\code\\checkersdata\\taggedevaluatedpositions+duplicates.txt", "r");
#endif
#endif
	
	printf("\nloading...");

	cur = ep; 
	i = 0; 
	j = 0;
	int maxindex = 0; 
	while (!feof(fp)) {
		
		// bm, bk, wm, wk, color, evaluation, result
		// evaluation is from side to move; BLACK to move is 2, WHITE to move is 1
		// result is WIN (1) if black won, LOSS (2) if white won, DRAW (0) or UNKNOWN (3)
		//fprintf(fpout, "%u %u %u %u %i %i %i %i\n", bm, bk, wm, wk, color, eval, v1, v3);
#ifdef AVERAGE
		// fprintf(fpout, "%u %u %u %u %i %i %i %i %i %i\n", bm, bk, wm, wk, color, games, points, v0, v1, v3);
		fscanf(fp, "%u %u %u %u %i %i %i %i %i %i %i\n", &bm, &bk, &wm, &wk, &color, &wins, &draws, &losses, &staticeval, &v1, &v3);


#else
		fscanf(fp, "%u %u %u %u %i %i %i %i %i\n", &bm, &bk, &wm, &wk, &color, &res_from_file, &staticeval, &v1, &v3);
#endif
		
		pos_num++;

		p.bm = bm;
		p.bk = bk; 
		p.wm = wm; 
		p.wk = wk; 
		p.color = color; 
		totalpositions += (wins + draws + losses); 

		/*if (wins + draws + losses > 100) {
			printboard(p);
			printf("\n%i wins %i draws %i losses %i static eval", wins, draws, losses, color == BLACK? staticeval:-staticeval);
			getch(); 
		}*/

		if (!testcapture(&p)) {
			p.color = p.color^CC; 
			if (!testcapture(&p)) {
				quiet_pos_num++; 
				totalquietpositions += (wins + draws + losses); 
				p.color = p.color^CC;
				cur->bm = bm;
				cur->bk = bk;
				cur->wm = wm;
				cur->wk = wk;
				cur->color = color;
				cur->value = v3;
				cur->searchvalue = v1; // value from a deeper search, currently 9 ply
#ifdef AVERAGE
				//cur->gameresult = (float)points / (float)(2 * games); 
				//cur->gamenum = games; 
				cur->wins = wins; 
				cur->draws = draws; 
				cur->losses = losses; 
#else
				cur->gameresult = res_from_file;
#endif
				
				mc.bm = bitcount(p.bm);
				mc.bk = bitcount(p.bk);
				mc.wm = bitcount(p.wm);
				mc.wk = bitcount(p.wk);
				//cur->staticeval = evaluation(&p, &mc, 0, &delta, 0, 0);
				//if (abs(cur->staticeval - cur->value) > 50) {
#ifdef REJECTNONQUIET
				if(abs(staticeval - v3) > 50) {
#ifdef AVERAGE
					rejectednum += (wins + draws + losses); 
					totalquietpositions -= (wins + draws + losses); 
					rejected++; 
#else
					rejected++;
#endif
					quiet_pos_num--;
					//printboard(p);
					//printf("\nthis position (%i) has evaluation %i but 3ply value %i", i, staticeval, v3);
					//getch();
				}
				else {
#endif
					cur++;
#ifdef AVERAGE
					totalgames += (wins + draws + losses);

#else
					totalgames++;
#endif

					int index = getindex(&p);

					if (index >= 0) {
						indexnum[index] += (wins + draws + losses);
					}

					int revindex = getreverseindex(&p);
					if (revindex >= 0) {
						indexnum[revindex] += (wins + draws + losses);
					}
					if (index <= 0 && revindex <= 0)
						unusedgames += (wins + draws + losses);
					else
						usedgames += (wins + draws + losses); 
				}
				
				if (i % 10000 == 0)
					printf("\n%i", i);
				i++;
			}
		}
	}

	
	int realized = 0; 
	for (int j = 0; j < MAXINDEX; j++) {
		if (indexnum[j] > 0)
			realized++;
	}
	printf("\nof 531441 possible 3-backrank indices, %i are actually realized (n>0)", realized);

	realized = 0;
	for (int j = 0; j < MAXINDEX; j++) {
		if (indexnum[j] > 10)
			realized++;
	}
	printf("\nof 531441 possible 3-backrank indices, %i are actually realized (n>10)", realized);

	realized = 0;
	for (int j = 0; j < MAXINDEX; j++) {
		if (indexnum[j] > 100)
			realized++;
	}
	printf("\nof 531441 possible 3-backrank indices, %i are actually realized (n>100)", realized);

	realized = 0;
	for (int j = 0; j < MAXINDEX; j++) {
		if (indexnum[j] > 1000)
			realized++;
	}
	printf("\nof 531441 possible 3-backrank indices, %i are actually realized (n>1000)", realized);

	printf("\n%i used games, %i unused games for pattern optimization", usedgames, unusedgames);
	



	fclose(fp); 
	n = i - 1 - rejected;
	printf("\ntotal unique positions %i, total positions %i, total quiet games %i, unique quiet %i, final %i, %i were rejected (%i games)", pos_num, totalpositions, totalquietpositions, quiet_pos_num, n, rejected, rejectednum);
	getch(); 
	printf("\nevaluating...");

	
#ifdef STOCHASTIC
	isinactive = malloc(n * sizeof(short int));
	for (i = 0; i < n; i++) {
		isinactive[i] = rand() % STOCHASTICNUM;
	}
#endif



	// intermezzo: save 1000 positions as fen to a text file for move ordering
	if (0) {
		printf("\ns saving 1000 positions...");
		fp = fopen("c:\\code\\checkersdata\\1000positions.txt", "w");
		for (i = 0; i < 1000; i++) {
			j = rand() + (rand() << 15);
			j = j % n;
			printf("\npos %i", j);
			p.bm = ep[j].bm;
			p.bk = ep[j].bk;
			p.wm = ep[j].wm;
			p.wk = ep[j].wk;
			p.color = ep[i].color;
			printboard(&p);
			PositiontoFEN(&p, FEN);
			fprintf(fp, "%s", FEN);
			fflush(fp);
			if (i % 100 == 0)
				getch();
		}
		fclose(fp);
		printf("\ndone saving"); 
		getch();
		
	}

	// step 1: find optimal constant for sigmoid
	/*float minc = 0; 
    minerror = 1000; 
	for(c = 0.02; c < 0.025; c+= 0.0002) {
		//printf("\n%.3f", c);
		//errorsum = 0; 
		//cur = ep; 

		errorsum = calc_error(n, ep, c);

		if ((errorsum) < minerror) {
			minerror = errorsum;
			minc = c;
		}
		printf("\n%.4f err=%.5f", c, errorsum);
	}
	printf("\nbest c is %.4f with %.5f error - hit key to continue", minc, minerror); 
	c = minc; 
	getch(); */

	double minc = 0.024;
    c = 0.024; 
	
	


	//for (i = 0; i < PARAMSOPT; i++)
	//	params[i] = 0;
	//params[7] = 130; // keep only king value
	//params[35] = 100; // and man value
	//params[59] = 10; // int badstructuremax1 = 20;
	
	//for (i = 0; i < PARAMSOPT; i++)
	//	notadjust[i] = 0; 

	// initialize 
	//initeval(); 
	//minerror = calc_error(n, ep, c);
	

	// reset all parameters to 0
	/*for (i = 0; i < PARAMS; i++)
		params[i] = 0;
	params[man_value] = 100; 
	params[king_value] = 130; 
	params[exchangebias] = 25; */
	//startparams(); 
	optimalparams(); 
#ifdef ZERO
	zeroparams(); 
	//for (i = 0; i < PARAMS; i++)
	//	params[i] = 0; 
	setparams(params, paramnum);
	updateeval();
#endif
	getparams(params, &paramnum); 

	/*
	for (i = 0; i < 256; i++) {
		params[arraystart + i + 13 + 256] = 0;
		params[arraystart + i + 13] = 0;
	}*/

	// to "stretch" eval
	//for (i = 0; i < PARAMS; i++)
	//	params[i] = 2 * params[i]; 

	setparams(params, paramnum);
	updateeval();
	
	getparams(params, &paramnum);
	/*for (i = 0; i < PARAMS; i++) {
		printf("\nparam %i: %i", i, params[i]); 
	}
	getch(); */
	for (i = 0; i < n; i++) 
		error_MT[i] = 0;
	minerror = calc_error_MT(n, ep, c);
	for (i = 0; i < n; i++)
		error_MT[i] = 0;
	printf("\ninitial error MT is %.10f", minerror);
	fprintf(log, "\ninitial error MT is %.10f", minerror);
	//minerror = 1; 

	//setparams(params, paramnum);
	//updateeval();
	if (1) {
		minerror = calc_error(n, ep, c);
		printf("\nerror after setting all parameters is %.10f (ST)", minerror);
	}
	printf("\nfound %i parameters to optimize - hit key to continue", paramnum); 
	getch(); 

	/*
	if (1) {
		zerobackrank(); 
		minerror = calc_error(n, ep, c);
		printf("\nerror after setting br to 0 is %.10f (ST)", minerror);
	}*/

	// if you want the pattern optimizer to run, use 2 lines below
	//patterns_init();
	//pattern_optimizer(n, ep, c);
	//getch(); 



	if (1) {
		minerror = calc_error(n, ep, c);
		printf("\nerror after turning off patterns is %.10f (ST)", minerror);
	}

	/*deactivate_all(); 
	active_set[man_value] = 1;
	active_set[king_value] = 1;
	active_set[piecedown_9] = 1;
	active_set[piecedown_11] = 1;
	active_set[twokingbonus_10] = 1;
	active_set[twokingbonus_12] = 1;
	active_set[exchangebias] = 1; */

	/*deactivate_all(); 
	for (i = 0; i < 256; i++) {
		active_set[arraystart + i + 13 + 256 + 25 + 10 + 32] = 1;
	}*/
	/*active_set[selftrap1] = 1; 
	active_set[selftrap2] = 1;
	active_set[selftrap3] = 1;
	active_set[selftrap4] = 1;
	active_set[selftrap5] = 1;
	active_set[selftrap6] = 1;
	active_set[selftrap7] = 1;*/

	

	int step = 1;
	int maxadjust = 100; 

	activate_all(); 

	//minerror = 1; 
	while (iterations < 1000) {
		changed = 0;
		sameadjust = 0; 
		for (j = 0; j < paramnum; j++) {  // for all params do
			// skip if parameter not activated
			if (active_set[j] == 0) {
				printf("\nskipping parameter %i", j);
				allactive = 0; 
				continue;
			}
	
			// save old value	
			oldparam = params[j];
			influence[j] = 0; 

			printf("\nparameter %i:%i", j, oldparam);
			// 1. try going in positive direction
			adjust = 0; 
			while (adjust < maxadjust) {
				params[j] = params[j]+step; 
				setparams(params, paramnum); 
				updateeval(); 
				error = calc_error_MT(n, ep, c);
				influence[j] += fabs(error - minerror);
				printf(" +(%.12f)", error); 
				if (error > (minerror - tolerance)) {
					// revert
					params[j] = params[j] - step; 
					break; 
				}
				adjust++; 
				minerror = error; 
				printf(" (%i)", params[j]);
			}

			// 2. if param was not adjusted in positive direction, try negative direction
			if (!adjust) {
				while (adjust < maxadjust) {
					params[j] -= step;
					setparams(params, paramnum);
					updateeval();
					error = calc_error_MT(n, ep, c);
					printf(" -(%.12f)", error);
					influence[j] += fabs(error - minerror);
					if (error > (minerror - tolerance)) {
						// revert
						params[j]+= step;
						break;
					}
					adjust++;

					minerror = error; 
					printf(" (%i)", params[j]);
				}
			}
			if (adjust) {
				changed++;
				printf("\n---------->>>> adjusted %s from %i to %i (%.6f)", strs[j], oldparam, params[j], minerror);
				fprintf(log, "\n---------->>>> adjusted %s from %i to %i (%.6f)", strs[j], oldparam, params[j], minerror);
			}
			else {
				printf("\n%s unchanged (%i)", strs[j], params[j]);
				fprintf(log, "\n%s unchanged (%i) - setting inactive!", strs[j], params[j]);
				active_set[j] = 0;
			}
		}
		printf("\niteration %i with %i changes (%.7f)-----------------", iterations, changed, minerror);
		fprintf(log, "\niteration %i with %i changes (%.7f)-----------------", iterations, changed, minerror);
		codeoutput(0);
		iterations++; 

		if (changed == 0 && allactive)
			break; 
		if (changed == 0) {
			printf("\nno changes on this iteration, but not all active - reactivating all");
			fprintf(log, "\nno changes on this iteration, but not all active - reactivating all");
			allactive = 1;
			activate_all();
#ifdef STOCHASTIC
			for (i = 0; i < n; i++) {
				isinactive[i] = rand() % STOCHASTICNUM;
				error_MT[i] = 0;
				}
			minerror = calc_error_MT(n, ep, c);
			printf("\nnew initial error MT is %.10f", minerror);
			fprintf(log, "\nnew initial error MT is %.10f", minerror);
#endif
		}		
	}

	// first write params directly
	codeoutput(0);

	// then write them after recalling from the eval
	// TODO: test what happens if I outcomment this, is influence then OK?
	// if yes, what does this mean for my code correctness???
	//codeoutput(1);
	activate_all();
	// find out what the influence of the parameters is overall:
	printf("\nmeasuring absolute influence of all parameters..."); 
	for (i = 0; i < paramnum; i++) {
		// skip if parameter not activated
		if (active_set[i] == 0)
			continue;
		
		printf(".");
		oldparam = params[i];
		params[i] = 0;
		setparams(params, paramnum);
		updateeval();
		error = calc_error_MT(n, ep, c);
		influence0[i] = error - minerror; 
		params[i] = oldparam;
	}

	fprintf(log, "\ninitial\toptimized");
	fp = fopen("C:\\code\\checkersdata\\param_influence.txt", "w");
	for (i = 0; i < paramnum; i++) {
		printf("\n%i:\t%i\t(%s)  (+-%.5f, +-%.5f)", i, params[i], strs[i], 1000.0 * influence[i], 1000.0 * influence0[i]);
		fprintf(fp, "%i\t%s\t%i\t%.5f\t%.5f\n", i, strs[i], params[i], 1000.0* influence[i], 1000.0* influence0[i]);
		fprintf(log, "\n%i\t%i\t%s", initialparams[i], params[i], strs[i]); 
	}
	fclose(fp); 
	printf("\n%i iterations made, no more improvement possible", iterations);
	printf("\nerror after optimization is %.7f", minerror);
	fprintf(log, "\nerror after optimization is %.7f", minerror);
	fclose(log); 
	
	printf("\nparameters written to c:\\code\\checkersdata\\codeoutput.txt");

	getch(); 
    return 0;
}

int activate_all() {

	/*
	deactivate_all(); 
	
	for (int i = 0; i < 150; i++)
		active_set[arraystart + i + 13 + BRNUM + 25 + 10 + 32] = 1;
	
	
	
	//active_set[edgepressure1] = 1; 
	return 0; 

	for (int i = 0; i < 7; i++)
		active_set[i] = 1; 

	for (int i = 0; i < BRNUM; i++) {
		active_set[arraystart + 13 + i] = 1;
	}


	//return 0; */

	for (int i = 0; i < PARAMS; i++)
		active_set[i] = 1;
	return 0; 
}

int deactivate_all() {
	for (int i = 0; i < PARAMS; i++)
		active_set[i] = 0;
	return 0; 
}

void codeoutput(int recall) {
	// write parameters as C code to file
	FILE* fp;
	int i; // , j;
	int paramnum = 0;

	//int br[256]; 
	

	if (recall != 0) {
		getparams(params, &paramnum);
		fp = fopen("C:\\code\\checkersdata\\codeoutputrecalled.txt", "w");
	}
	else {
		fp = fopen("C:\\code\\checkersdata\\codeoutput.txt", "w");
		paramnum = PARAMS; 
	}
	
	
	// print parameters to show it's working
	//for (i = 0; i < paramnum; i++)
	//	fprintf(fp, "\nparameter[%i] is %i (%s)", i, params[i], strs[i]);
	//fprintf(fp, "\nfound %i parameters to optimize", paramnum);

	for (i = 0; i < paramnum - 13 - 25 - BRNUM - 10 - 32; i++) {
		fprintf(fp, "\nv[%s] = %i;", strs[i], params[i]);
	}

	//static int ungroundedpenalty[13] = { -1,-1,1,5,10,16,21,27,24,24,21,21,21 }; // optimized

	fprintf(fp, "\n\nstatic int ungroundedpenalty[13] = {");
	for (i = paramnum - 13 - 25 - BRNUM  - 10 - 32 ; i < paramnum - 25 - BRNUM  - 10 - 32 ; i++) {
		fprintf(fp, " %i,", params[i]);
	}
	fprintf(fp, "};");

	fprintf(fp, "\nstatic int backrank[BRNUM] = {");
	for (i = paramnum - 25 - BRNUM - 10 - 32 ; i < paramnum - 25  - 10 - 32 ; i++) {
		fprintf(fp, " %i,", params[i]);
		if ((i - paramnum + 25 + BRNUM + 10 + 32 ) % 16 == 0)
			fprintf(fp, "\n");
	}
	fprintf(fp, "};");

	fprintf(fp, "\nstatic int tmod[25] = {");
	for (i = paramnum - 25-10-32; i < paramnum-10-32; i++) {
		fprintf(fp, " %i,", params[i]);
	}
	fprintf(fp, "};");

	fprintf(fp, "\nstatic int kingmobility[10] = {");
	for (i = paramnum - 10-32; i < paramnum-32; i++) {
		fprintf(fp, " %i,", params[i]);
	}
	fprintf(fp, "};");

	fprintf(fp, "\nstatic int king_pst[32] = {");
	for (i = paramnum - 32; i < paramnum; i++) {
		fprintf(fp, " %i,", params[i]);
	}
	fprintf(fp, "};");

	/*fprintf(fp, "\nstatic int singlecorner[150] = {");
	for (i = paramnum - 150; i < paramnum; i++) {
		fprintf(fp, " %i,", params[i]);
	}
	fprintf(fp, "};");*/

	fclose(fp);
}

unsigned __stdcall subThread(void* pArguments)
{
	THREADINFO* threadinfo; 
	int i = 0; 
	
	threadinfo = (THREADINFO*)pArguments; 
	double c = threadinfo->c;
	POSITION p;
	MATERIALCOUNT mc;
	int staticeval;
	int delta = 0;
	double res = 0, error = 0, errorsum = 0;
	int num = 0;
	double sum;
	double s;
	int games; 

	//printf("In sub thread[%i]: %i...%i\n", threadinfo->threadID, threadinfo->start, threadinfo->end);

	threadinfo->errorsum = 0; 
	for (i = threadinfo->start; i < threadinfo->end; i++) {
#ifdef STOCHASTIC
		if (isinactive[i])
			continue; 
#endif
		p.bm = threadinfo->ep[i].bm;
		p.bk = threadinfo->ep[i].bk;
		p.wm = threadinfo->ep[i].wm;
		p.wk = threadinfo->ep[i].wk;
		p.color = threadinfo->ep[i].color;

		mc.bm = bitcount(p.bm);
		mc.bk = bitcount(p.bk);
		mc.wm = bitcount(p.wm);
		mc.wk = bitcount(p.wk);
		staticeval = evaluation(&p, &mc, 0, &delta, 0, 0);
#ifdef AVERAGE
		//num += threadinfo->ep[i].gamenum;

		games = threadinfo->ep[i].wins + threadinfo->ep[i].draws + threadinfo->ep[i].losses; 
		num += games;

		//printf("\n%i wins, %i draws, %i losses", threadinfo->ep[i].wins, threadinfo->ep[i].draws, threadinfo->ep[i].losses);
#else
		num++;
#endif
		//errorsum += abs(staticeval - ep[i].value);

		//printboard(&p); 
		//printf("\nstatic eval is %i", staticeval); 
		//getch(); 

		// logistic optimization
		// staticeval was computed as side to move. normalize to black to move
		if (threadinfo->ep[i].color == WHITE)
			staticeval = -staticeval; // now staticeval is as seen from black's point of view
#ifdef AVERAGE
#ifdef OPTIMIZE_SEARCHEVAL
		res = threadinfo->ep[i].searchvalue;
		if (threadinfo->ep[i].color == WHITE)
			res = -res; // now staticeval is as seen from black's point of view
		res = sigmoid(res, c);
		error = (res - sigmoid(staticeval, c));
		error = error * error;
		error *= (threadinfo->ep[i].wins + threadinfo->ep[i].draws + threadinfo->ep[i].losses); 
		threadinfo->errorsum += error; 
		error_MT[i] = error; 
#else
		s = sigmoid(staticeval, c); 
		error = (1 - s);
		error = error * error; 
		sum = error * threadinfo->ep[i].wins; 
		
		error = (0 - s);
		error = error * error;
		sum += error * threadinfo->ep[i].draws;
		
		error = (-1 - s);
		error = error * error;
		sum += error * threadinfo->ep[i].losses;
		threadinfo->errorsum  += sum;
		error_MT[i] = sum;
#endif

#else
		res = result_translated[threadinfo->ep[i].gameresult];

#ifdef OPTIMIZE_SEARCHEVAL
		res = threadinfo->ep[i].searchvalue;
		if (threadinfo->ep[i].color == WHITE)
			res = -res; // now staticeval is as seen from black's point of view
		res = sigmoid(res, c);
#endif
		// res is game result as seen from black's point of view (1 = win, 0 = draw, -1 = loss)
		error = (res - sigmoid(staticeval, c));

		error = error * error;
		printf("\nerror is %f", error);
		errorsum += error;
		error_MT[i] = error;
#endif



#ifdef AVERAGE
		//error = error * (threadinfo->ep[i].wins + threadinfo->ep[i].draws + threadinfo->ep[i].losses);
#endif

		//printboard(&p);
		//printf("\nstatic eval, search eval: %i %i", staticeval, eval);
		//getch();

	}
	//errorsum = errorsum / (float)num;
	//printf("\n***** %.6f",errorsum);

	//printf("\nDone sub thread[%i]: errorsum is %.7f", threadinfo->threadID, errorsum/(float)num);
	//printf("\ncalc MT[%i]: errorsum is %.2f, number is %i", threadinfo->threadID,errorsum, num);

	//threadinfo->errorsum = errorsum; 
	threadinfo->gamenum = num; 
	_endthreadex(0);
	return 0;
}

double calc_error_MT(int n, EVALUATEDPOSITION* ep, double c) {
	//int calc_error_MT() {
	// main function to call to run the calculation of the error in a multithreaded mode
	HANDLE hThread[4];
	unsigned threadID[4];
	int counter[4]; 
	THREADINFO threadinfo[4]; 
	double error;

	//printf("Creating subthreads...\n");

	threadinfo[0].ep = ep; 
	threadinfo[0].errorsum = 0; 
	threadinfo[0].threadID = 0; 
	threadinfo[0].start = 0; 
	threadinfo[0].end = n/4 ; 
	threadinfo[0].c = c; 
	threadinfo[0].gamenum = 0; 

	threadinfo[1].ep = ep;
	threadinfo[1].errorsum = 0;
	threadinfo[1].threadID = 1;
	threadinfo[1].start = n/4;
	threadinfo[1].end = n/2;
	threadinfo[1].c = c;
	threadinfo[1].gamenum = 0; 

	threadinfo[2].ep = ep;
	threadinfo[2].errorsum = 0;
	threadinfo[2].threadID = 2;
	threadinfo[2].start = n / 2;
	threadinfo[2].end = (3*n)/4;
	threadinfo[2].c = c;
	threadinfo[2].gamenum = 0;

	threadinfo[3].ep = ep;
	threadinfo[3].errorsum = 0;
	threadinfo[3].threadID = 3;
	threadinfo[3].start = (3 * n) / 4;
	threadinfo[3].end = n;
	threadinfo[3].c = c;
	threadinfo[3].gamenum = 0;

	//counter[0] = 1000000000; 
	//counter[1] = 2000000000; 

	// Create the second thread.
	// parameter 4 would be a pointer to an argument list = I could pass a structure there which would 
	// contain information to communicate with the thread
	hThread[0] = (HANDLE)_beginthreadex(NULL, 0, &subThread, &(threadinfo[0]), 0, &(threadID[0]));
	hThread[1] = (HANDLE)_beginthreadex(NULL, 0, &subThread, &(threadinfo[1]), 0, &(threadID[1]));
	hThread[2] = (HANDLE)_beginthreadex(NULL, 0, &subThread, &(threadinfo[2]), 0, &(threadID[2]));
	hThread[3] = (HANDLE)_beginthreadex(NULL, 0, &subThread, &(threadinfo[3]), 0, &(threadID[3]));
	// Wait until second thread terminates. If you comment out the line
	// below, Counter will not be correct because the thread has not
	// terminated, and Counter most likely has not been incremented to
	// 1000000 yet.
	//WaitForSingleObject(hThread[0], INFINITE);
	//WaitForSingleObject(hThread[1], INFINITE);
	WaitForMultipleObjects(4, hThread, TRUE, INFINITE);

	//     WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

	//printf("Counters are-> %d %d\n", counter[0], counter[1]);
	// Destroy the thread object.
	CloseHandle(hThread[0]);
	CloseHandle(hThread[1]);
	CloseHandle(hThread[2]);
	CloseHandle(hThread[3]);

	//printf("\nerrorsum 1 is %.7f, errorsum2 is %.7f", threadinfo[0].errorsum, threadinfo[1].errorsum);

	//error = threadinfo[0].errorsum + threadinfo[1].errorsum; 
	//error = error / (threadinfo[0].gamenum + threadinfo[1].gamenum);

	// now use the stored error info
	double errorsum = 0;
	for (int i = 0; i < n; i++) {
		errorsum += error_MT[i]; 
	}
	error = errorsum / (threadinfo[0].gamenum + threadinfo[1].gamenum + threadinfo[2].gamenum + threadinfo[3].gamenum);
	//error = errorsum / n;
	//printf("\nusing error array: ");
	//printf("\ntotal error %.2f", errorsum);
	//printf("\nnumber of games %i", n);
	//printf("\ngiving av. error of %.10f", error);

	/*printf("\n\nusing threads:");
	error = threadinfo[0].errorsum + threadinfo[1].errorsum + threadinfo[2].errorsum + threadinfo[3].errorsum; 
	printf("\ntotal error from 4 threads is %.2f", error);
	printf("\nnumber of games %i", threadinfo[0].gamenum + threadinfo[1].gamenum + threadinfo[2].gamenum + threadinfo[3].gamenum);
	error = error / (threadinfo[0].gamenum + threadinfo[1].gamenum + threadinfo[2].gamenum + threadinfo[3].gamenum); 
	printf("\naverage error of %.10f", error);*/


	return error; 
}

int pattern_optimizer(int n, EVALUATEDPOSITION* ep, double c) {
	// here's what the pattern optimizer has to do:
	int i; 
	POSITION p;
	MATERIALCOUNT mc;
	int delta; 
	int* staticeval; 
	double* changeplus;
	double* changeminus;
	double* weights; 
	double error;
	double errormodified; 

	
	double sum; 
	int adjustplus = 1, adjustminus = 1; 
	int pass = 1; 

	int num; double errorsum; int res;

	staticeval = malloc(n * sizeof(int));
	changeplus = malloc(MAXINDEX * sizeof(double));
	changeminus = malloc(MAXINDEX * sizeof(double));
	weights = malloc(MAXINDEX * sizeof(double));

	if (staticeval == 0 || changeplus == 0 || changeminus == 0 || weights == 0) {
		printf("\nnull pointer in pattern optimizer!");
		return 0;
	}

	for (i = 0; i < MAXINDEX; i++) {
		weights[i] = 0;
	}

	// if you want to load patterns do it here
	//loadpatterns(weights); 
	// set patterns in eval to 0
	patterns_init(); 

	// 1. calculate current eval of each position without changes and save in an array of size N
	printf("\npattern optimizer: getting initial eval for %i positions....", n);
	for (i = 0; i < n; i++) {
		p.bm = ep[i].bm;
		p.bk = ep[i].bk;
		p.wm = ep[i].wm;
		p.wk = ep[i].wk;
		p.color = ep[i].color;

		mc.bm = bitcount(p.bm);
		mc.bk = bitcount(p.bk);
		mc.wm = bitcount(p.wm);
		mc.wk = bitcount(p.wk);
		staticeval[i] = evaluation(&p, &mc, 0, &delta, 0, 0);
		if (ep[i].color == WHITE)
			staticeval[i] = -staticeval[i]; // now staticeval is as seen from black's point of view
	}
	printf(" done!");

	while (adjustplus + adjustminus  && (pass < 1550)) {
		// 2. create two arrays "changeplus[531441]" and "changeminus[531441]", and set them all to 0
		for (i = 0; i < MAXINDEX; i++) {
			changeplus[i] = 0;
			changeminus[i] = 0;
		}

		// new: for each pass, compute error:
		errorsum = 0;
		num = 0;
		for (i = 0; i < n; i++) {
			p.bm = ep[i].bm;
			p.bk = ep[i].bk;
			p.wm = ep[i].wm;
			p.wk = ep[i].wk;
			p.color = ep[i].color;
			int index = getindex(&p);   // maybe just replace with &ep[i]?
			int reverseindex = getreverseindex(&p);
			double w = 0; 
			
			if (index != -1)
				w = weights[index];
			
			if (reverseindex != -1)
				w -= weights[reverseindex]; 
			
#ifdef AVERAGE
			num += (ep[i].wins + ep[i].draws + ep[i].losses);
			error = (1.0 - sigmoid((double)staticeval[i] + w, c));
			error = error * error;
			sum = error * ep[i].wins;
			error = (0.0 - sigmoid((double)staticeval[i] + w, c));
			error = error * error;
			sum += error * ep[i].draws;
			error = (-1.0 - sigmoid((double)staticeval[i] + w, c));
			error = error * error;
			sum += error * ep[i].losses;
			if (sum != sum) {
				printf("\n%i! %i %.2f %.2f", i, staticeval[i], weights[index], weights[reverseindex]);
				getch();
			}
			errorsum += sum;
#endif
		}
		errorsum = errorsum / (double)num;
		printf("\nerror sum is %.12f", errorsum);



		// 3. loop over all N positions
		for (i = 0; i < n; i++) {
			p.bm = ep[i].bm;
			p.bk = ep[i].bk;
			p.wm = ep[i].wm;
			p.wk = ep[i].wk;
			p.color = ep[i].color;

			//    4.calculate index of this position
			int index = getindex(&p);
			int reverseindex = getreverseindex(&p);
			if (index == reverseindex) {
				//printf("!"); 
				continue; // any change would cancel out in this position!
			}
			//    5.adjust weight[index] by +1, evaluate position (actually, just add weight[index]+1 to the eval! no need to really evaluate!)
			//    6.calculate difference of sigmoid function for old and new eval  (sigmoid(old) - sigmoid(new))
			//    7.add this difference to changeplus[index]
			//    8.adjust weight[index]  by -1, evaluate position (actually, just add weight[index]-1 to the eval! no need to really evaluate!)
			//	  9.calculate difference of sigmoid function for old and new eval
			//    10.add this difference to changeminus[index]
			if (index != -1) {
				if (abs(weights[index]) > 30 && (indexnum[index] > 100)  && ((pass %100) == 0) && (p.wk&0xF)) {
					printboard(&p);
					printf("\nindex is %i, weight is %.1f, static eval %i, games %i, %i (W%i D%i L%i)", index, weights[index], staticeval[i], indexnum[index], ep[i].wins+ep[i].draws+ep[i].losses, ep[i].wins, ep[i].draws, ep[i].losses);
				}

				error = (1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].losses;

				changeplus[index] += sum;
				changeminus[index] += sum;

				error = (1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeplus[index] -= sum;

				error = (1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeminus[index] -= sum;


			}

			if (reverseindex != -1) {
				//	  11. calculate reverseindex - if it is different than index, repeat steps 5.-10. for reverseindex
				error = (1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].losses;

				changeplus[reverseindex] += sum;
				changeminus[reverseindex] += sum;

				error = (1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeplus[reverseindex] -= sum;

				error = (1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeminus[reverseindex] -= sum;
			}
		}

		adjustplus = 0;
		adjustminus = 0;

		// find index with greatest change
		double maxchange = 0; 
		for (i = 0; i < MAXINDEX; i++) {
			if (changeplus[i] > maxchange)
				maxchange = changeplus[i];
			if (changeminus[i] > maxchange)
				maxchange = changeminus[i]; 
		}
		printf("\nmax change is %.8f", maxchange);

		//double mult = 1.0;
		for (i = 0; i < MAXINDEX; i++) {
			// example: if a pattern shows up 25 times, it is limited to value 25
			// for 100 times, limited to 50
			// for 400 times, to 100
			// if a pattern is very rare, it only has a tiny change, and hardly gets anywhere
			double mult = 1.0;
			// multiplier should be 1 for 1000, 2 for 100, 3 for 10, 4 for 1
			//if (indexnum[i] < 1000) {
			//if (indexnum[i] < 100) {
			//		mult = 5 - 2 * log10((double)indexnum[i]);
				//mult = 13 - 4 * log10((double)indexnum[i]);
//				mult = 17 - 4 * log10((double)indexnum[i]);
				//mult = 81 - 20 * log10((double)indexnum[i]);

				// mult = 25 - 8* log10((double)indexnum[i]);
			//}
			mult *= 0.6; 
			//if (changeplus[i] > 0 && (abs(weights[i]) < 5 * sqrt(indexnum[i]))) {
			if (changeplus[i] > 0 && (abs(weights[i]) < 5 * sqrt(indexnum[i]))) {
					adjustplus++;
				// Ed's suggestion for regularization:
				//weights[i] *= 0.9999;// 0.998;
				weights[i] += mult*changeplus[i];
				//printf("\nadjusted index %i to %.1f", i, weights[i]); 
				//getch(); 
			}
			//else if (changeminus[i] > 0 && (abs(weights[i]) < 5 * sqrt(indexnum[i]))) {
			else if (changeminus[i] > 0 && (abs(weights[i]) < 5 * sqrt(indexnum[i]))) {
				adjustminus++;
				//weights[i] *= 0.9999; // 0.998;
				weights[i] -= mult*changeminus[i];
				//printf("\nadjusted index %i to %.1f", i, weights[i]);
				//getch(); 
			}
		}
		printf("\npattern optimizer: pass %i done, found %i patterns to adjust +, and %i patterns to adjust -!", pass, adjustplus, adjustminus);
		pass++; 

	}
	// 12. after loop is done, loop over all weights (531441 of them)
	//    13. if changeplus[index] is positive, add one to weight[index]
	//    14. else if changeminus[index] is positive, subract one from weight[index]
	// 15. if any changes were made, go back to step 3.
	getch();

	// write a file with pattern weights
	// write parameters as C code to file
	FILE* fp;
	fp = fopen("C:\\code\\checkersdata\\patternoutput.txt", "w");

	int nonzero = 0; 
	for (i = 0; i < MAXINDEX; i++) {
		if (((int)weights[i]) != 0) {
			fprintf(fp, "pat1[%i] = %i;\n", i, ((int)(2*weights[i])));  // cake eval divides weights by two, so write 2*weights
			nonzero++;
		}
	}
	fclose(fp); 
	printf("\n%i weights of 531441 are nonzero - hit key to continue", nonzero);
	getch(); 



	// write a file with pattern weights but better:
	// write parameters as C code to file
	//FILE* fp;
	fp = fopen("C:\\code\\checkersdata\\patternoutput_rounded.txt", "w");

	//int nonzero = 0;
	int w; 
	for (i = 0; i < MAXINDEX; i++) {
		w = round(2 * weights[i]); 
		if (w != 0) {
			fprintf(fp, "pat1[%i] = %i;\n", i, w);  // cake eval divides weights by two, so write 2*weights
			nonzero++;
		}
	}
	fclose(fp);
	printf("\n%i weights of 531441 are nonzero - hit key to continue", nonzero);
	getch();


	// finally, calculate what will happen with the weights rounded to nearest integers:
	for (i = 0; i < MAXINDEX; i++) {
		weights[i] = round(2 * weights[i]); 
		weights[i] /= 2; 
	}
	errorsum = 0;
	num = 0;
	for (i = 0; i < n; i++) {
		p.bm = ep[i].bm;
		p.bk = ep[i].bk;
		p.wm = ep[i].wm;
		p.wk = ep[i].wk;
		p.color = ep[i].color;
		int index = getindex(&p);   // maybe just replace with &ep[i]?
		int reverseindex = getreverseindex(&p);
		double w = 0;

		if (index != -1)
			w = weights[index];

		if (reverseindex != -1)
			w -= weights[reverseindex];

#ifdef AVERAGE
		num += (ep[i].wins + ep[i].draws + ep[i].losses);
		error = (1.0 - sigmoid((double)staticeval[i] + w, c));
		error = error * error;
		sum = error * ep[i].wins;
		error = (0.0 - sigmoid((double)staticeval[i] + w, c));
		error = error * error;
		sum += error * ep[i].draws;
		error = (-1.0 - sigmoid((double)staticeval[i] + w, c));
		error = error * error;
		sum += error * ep[i].losses;
		if (sum != sum) {
			printf("\n%i! %i %.2f %.2f", i, staticeval[i], weights[index], weights[reverseindex]);
			getch();
		}
		errorsum += sum;
#endif
	}
	errorsum = errorsum / (double)num;
	printf("\nerror sum after rounding is is %.12f", errorsum);
	getch(); 

}



int pattern_optimizer_br(int n, EVALUATEDPOSITION* ep, double c) {
	// here's what the pattern optimizer has to do:
	int i;
	POSITION p;
	MATERIALCOUNT mc;
	int delta;
	int* staticeval;
	double* changeplus;
	double* changeminus;
	double* weights;
	double error;
	double errormodified;


	double sum;
	int adjustplus = 1, adjustminus = 1;
	int pass = 1;

	int num; double errorsum; int res;

	int patnum = 4096; 

	staticeval = malloc(n * sizeof(int));
	changeplus = malloc(patnum * sizeof(double));
	changeminus = malloc(patnum * sizeof(double));
	weights = malloc(patnum * sizeof(double));

	if (staticeval == 0 || changeplus == 0 || changeminus == 0 || weights == 0) {
		printf("\nnull pointer in pattern optimizer!");
		return 0;
	}

	for (i = 0; i < patnum; i++) {
		weights[i] = 0;
	}

	// if you want to load patterns do it here
	//loadpatterns(weights); 
	// set patterns in eval to 0
	patterns_init();

	// 1. calculate current eval of each position without changes and save in an array of size N
	printf("\npattern optimizer: getting initial eval for %i positions....", n);
	for (i = 0; i < n; i++) {
		p.bm = ep[i].bm;
		p.bk = ep[i].bk;
		p.wm = ep[i].wm;
		p.wk = ep[i].wk;
		p.color = ep[i].color;

		mc.bm = bitcount(p.bm);
		mc.bk = bitcount(p.bk);
		mc.wm = bitcount(p.wm);
		mc.wk = bitcount(p.wk);
		staticeval[i] = evaluation(&p, &mc, 0, &delta, 0, 0);
		if (ep[i].color == WHITE)
			staticeval[i] = -staticeval[i]; // now staticeval is as seen from black's point of view
	}
	printf(" done!");

	while (adjustplus + adjustminus && (pass < 1550)) {
		// 2. create two arrays "changeplus[531441]" and "changeminus[531441]", and set them all to 0
		for (i = 0; i < patnum; i++) {
			changeplus[i] = 0;
			changeminus[i] = 0;
		}

		// new: for each pass, compute error:
		errorsum = 0;
		num = 0;
		for (i = 0; i < n; i++) {
			p.bm = ep[i].bm;
			p.bk = ep[i].bk;
			p.wm = ep[i].wm;
			p.wk = ep[i].wk;
			p.color = ep[i].color;
			int index = getindex(&p);
			int reverseindex = getreverseindex(&p);
			double w = 0;

			w = weights[index];
			w += weights[reverseindex];

#ifdef AVERAGE
			num += (ep[i].wins + ep[i].draws + ep[i].losses);
			error = (1.0 - sigmoid((double)staticeval[i] + w, c));
			error = error * error;
			sum = error * ep[i].wins;
			error = (0.0 - sigmoid((double)staticeval[i] + w, c));
			error = error * error;
			sum += error * ep[i].draws;
			error = (-1.0 - sigmoid((double)staticeval[i] + w, c));
			error = error * error;
			sum += error * ep[i].losses;
			if (sum != sum) {
				printf("\n%i! %i %.2f %.2f", i, staticeval[i], weights[index], weights[reverseindex]);
				getch();
			}
			errorsum += sum;
#endif
		}
		errorsum = errorsum / (double)num;
		printf("\nerror sum is %.12f", errorsum);



		// 3. loop over all N positions
		for (i = 0; i < n; i++) {
			p.bm = ep[i].bm;
			p.bk = ep[i].bk;
			p.wm = ep[i].wm;
			p.wk = ep[i].wk;
			p.color = ep[i].color;

			//    4.calculate index of this position
			int index = getindex(&p);
			int reverseindex = getreverseindex(&p);
			if (index == reverseindex) {
				//printf("!"); 
				continue; // any change would cancel out in this position!
			}
			//    5.adjust weight[index] by +1, evaluate position (actually, just add weight[index]+1 to the eval! no need to really evaluate!)
			//    6.calculate difference of sigmoid function for old and new eval  (sigmoid(old) - sigmoid(new))
			//    7.add this difference to changeplus[index]
			//    8.adjust weight[index]  by -1, evaluate position (actually, just add weight[index]-1 to the eval! no need to really evaluate!)
			//	  9.calculate difference of sigmoid function for old and new eval
			//    10.add this difference to changeminus[index]
			if (index != -1) {
				if (abs(weights[index]) > 30 && (indexnum[index] > 100) && ((pass % 100) == 0) && (p.wk & 0xF)) {
					printboard(&p);
					printf("\nindex is %i, weight is %.1f, static eval %i, games %i, %i (W%i D%i L%i)", index, weights[index], staticeval[i], indexnum[index], ep[i].wins + ep[i].draws + ep[i].losses, ep[i].wins, ep[i].draws, ep[i].losses);
				}

				error = (1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].losses;

				changeplus[index] += sum;
				changeminus[index] += sum;

				error = (1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeplus[index] -= sum;

				error = (1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1.0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeminus[index] -= sum;


			}

			if (reverseindex != -1) {
				//	  11. calculate reverseindex - if it is different than index, repeat steps 5.-10. for reverseindex
				error = (1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex], c));
				error = error * error;
				sum += error * ep[i].losses;

				changeplus[reverseindex] += sum;
				changeminus[reverseindex] += sum;

				error = (1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] + 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeplus[reverseindex] -= sum;

				error = (1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum = error * ep[i].wins;

				error = (0 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].draws;

				error = (-1 - sigmoid((double)staticeval[i] + weights[index] - weights[reverseindex] - 0.1, c));
				error = error * error;
				sum += error * ep[i].losses;
				changeminus[reverseindex] -= sum;
			}
		}

		adjustplus = 0;
		adjustminus = 0;

		// find index with greatest change
		double maxchange = 0;
		for (i = 0; i < patnum; i++) {
			if (changeplus[i] > maxchange)
				maxchange = changeplus[i];
			if (changeminus[i] > maxchange)
				maxchange = changeminus[i];
		}
		printf("\nmax change is %.8f", maxchange);

		//double mult = 1.0;
		for (i = 0; i < patnum; i++) {
			// example: if a pattern shows up 25 times, it is limited to value 25
			// for 100 times, limited to 50
			// for 400 times, to 100
			// if a pattern is very rare, it only has a tiny change, and hardly gets anywhere
			double mult = 1.0;
			// multiplier should be 1 for 1000, 2 for 100, 3 for 10, 4 for 1
			//if (indexnum[i] < 1000) {
			if (indexnum[i] < 100) {
				mult = 7 - 2 * log10((double)indexnum[i]);
			   //mult = 13 - 4 * log10((double)indexnum[i]);
//				mult = 17 - 4 * log10((double)indexnum[i]);
				//mult = 81 - 20 * log10((double)indexnum[i]);

				// mult = 25 - 8* log10((double)indexnum[i]);
			}
			mult *= 0.8; 
			//if (changeplus[i] > 0 && (abs(weights[i]) < 5 * sqrt(indexnum[i]))) {
			if (changeplus[i] > 0 && (abs(weights[i]) < 50 * sqrt(indexnum[i]))) {
				adjustplus++;
				// Ed's suggestion for regularization:
				//weights[i] *= 0.9999;// 0.998;
				weights[i] += mult * changeplus[i];
				//printf("\nadjusted index %i to %.1f", i, weights[i]); 
				//getch(); 
			}
			//else if (changeminus[i] > 0 && (abs(weights[i]) < 5 * sqrt(indexnum[i]))) {
			else if (changeminus[i] > 0 && (abs(weights[i]) < 50 * sqrt(indexnum[i]))) {
				adjustminus++;
				//weights[i] *= 0.9999; // 0.998;
				weights[i] -= mult * changeminus[i];
				//printf("\nadjusted index %i to %.1f", i, weights[i]);
				//getch(); 
			}
		}
		printf("\npattern optimizer: pass %i done, found %i patterns to adjust +, and %i patterns to adjust -!", pass, adjustplus, adjustminus);
		pass++;

	}
	// 12. after loop is done, loop over all weights (531441 of them)
	//    13. if changeplus[index] is positive, add one to weight[index]
	//    14. else if changeminus[index] is positive, subract one from weight[index]
	// 15. if any changes were made, go back to step 3.
	getch();

	// write a file with pattern weights
	// write parameters as C code to file
	FILE* fp;
	fp = fopen("C:\\code\\checkersdata\\patternoutput_br.txt", "w");

	int nonzero = 0;
	for (i = 0; i < patnum; i++) {
		if (((int)weights[i]) != 0) {
			fprintf(fp, "pat1[%i] = %i;\n", i, ((int)(2 * weights[i])));  // cake eval divides weights by two, so write 2*weights
			nonzero++;
		}
	}
	fclose(fp);
	printf("\n%i weights of %i are nonzero - hit key to continue", patnum, nonzero);
	getch();
}




double calc_error(int n, EVALUATEDPOSITION* ep, double c) {
	int i;
	POSITION p;
	MATERIALCOUNT mc;
	int staticeval;
	int delta;
	double res, error, errorsum = 0;
	double sum;
	int num = 0; 

	 
	for (i = 0; i < n; i++) {
#ifdef STOCHASTIC
		if (isinactive[i])
			continue;
#endif
		p.bm = ep[i].bm;
		p.bk = ep[i].bk;
		p.wm = ep[i].wm;
		p.wk = ep[i].wk;
		p.color = ep[i].color;

		mc.bm = bitcount(p.bm);
		mc.bk = bitcount(p.bk);
		mc.wm = bitcount(p.wm);
		mc.wk = bitcount(p.wk);
		staticeval = evaluation(&p, &mc, 0, &delta, 0, 0);


		//errorsum += abs(staticeval - ep[i].value);

		//printboard(&p); 
		//printf("\nstatic eval is %i", staticeval); 
		//getch(); 

		// logistic optimization
		// staticeval was computed as side to move. normalize to black to move
		if (ep[i].color == WHITE)
			staticeval = -staticeval; // now staticeval is as seen from black's point of view
#ifdef AVERAGE
#ifdef OPTIMIZE_SEARCHEVAL

		res = ep[i].searchvalue;
		if (ep[i].color == WHITE)
			res = -res; // now staticeval is as seen from black's point of view
		res = sigmoid(res, c);
		error = (res - sigmoid(staticeval, c));
		error = error * error;
		error *= (ep[i].wins + ep[i].draws + ep[i].losses);
		errorsum += error; 
		error_ST[i] = error;
		num += (ep[i].wins + ep[i].draws + ep[i].losses);

#else
		num += (ep[i].wins + ep[i].draws + ep[i].losses);
		error = (1 - sigmoid((double)staticeval, c));
		error = error * error;
		sum = error * ep[i].wins;

		error = (0 - sigmoid((double)staticeval, c));
		error = error * error;
		sum += error * ep[i].draws;

		error = (-1 - sigmoid((double)staticeval, c));
		error = error * error;
		sum += error * ep[i].losses;

		errorsum += sum;
		error_ST[i] = sum;
#endif
#else
		// res is game result as seen from black's point of view (1 = win, 0 = draw, -1 = loss
		res = result_translated[ep[i].gameresult];

#ifdef OPTIMIZE_SEARCHEVAL
		res = ep[i].searchvalue; 
		if (ep[i].color == WHITE)
			res = -res; // now staticeval is as seen from black's point of view
		res = sigmoid(res, c); 
#endif
		error = (res - sigmoid(staticeval, c));
		error = error * error;
		errorsum += error;
		error_ST[i] = error;
		num++;
#endif

		//if (i == n / 2)
		//	printf("\ncalc standard @n/2: %.2f (%i games)", errorsum, num);
		//printboard(&p);
		//printf("\nstatic eval, search eval: %i %i", staticeval, eval);
		//getch();
	}
	//printf("\ncalc standard: errorsum is %.2f, number is %i", errorsum, num);

	errorsum = errorsum / (double)num;
	
	return errorsum;
}


double sigmoid(double v, double c) {
	double res;
	//float c = 0.02; 
	//res = exp(0.001);

	res = 2 / (1 + exp((double) (-c * ((double)v)))) - 1;
	return res; 
}



int testcapture(POSITION *p)
{
	// testcapture returns 1 if the side to move has a capture.
	unsigned int black, white, free, m;

	black = p->bm | p->bk;
	white = p->wm | p->wk;
	free = ~(black | white);
	if (p->color == BLACK)
	{
		m = ((((black&LFJ2) << 4)&white) << 3);
		m |= ((((black&LFJ1) << 3)&white) << 4);
		m |= ((((black&RFJ1) << 4)&white) << 5);
		m |= ((((black&RFJ2) << 5)&white) << 4);
		if (p->bk)
		{
			m |= ((((p->bk&LBJ1) >> 5)&white) >> 4);
			m |= ((((p->bk&LBJ2) >> 4)&white) >> 5);
			m |= ((((p->bk&RBJ1) >> 4)&white) >> 3);
			m |= ((((p->bk&RBJ2) >> 3)&white) >> 4);
		}
	}
	else
	{
		m = ((((white&LBJ1) >> 5)&black) >> 4);
		m |= ((((white&LBJ2) >> 4)&black) >> 5);
		m |= ((((white&RBJ1) >> 4)&black) >> 3);
		m |= ((((white&RBJ2) >> 3)&black) >> 4);
		if (p->wk)
		{
			m |= ((((p->wk&LFJ2) << 4)&black) << 3);
			m |= ((((p->wk&LFJ1) << 3)&black) << 4);
			m |= ((((p->wk&RFJ1) << 4)&black) << 5);
			m |= ((((p->wk&RFJ2) << 5)&black) << 4);
		}
	}
	if (m & free)
		return 1;
	return 0;
}


// some helper functions

int32 attack_forwardjump(int32 x, int32 free)
{
	// return all squares which are forward-attacked by pieces in x, with free
	return (((((x&LFJ1) << 3)&free)&(free >> 4)) | ((((x&LFJ2) << 4)&free)&(free >> 3)) | ((((x&RFJ1) << 4)&free)&(free >> 5)) | ((((x&RFJ2) << 5)&free)&(free >> 4)));
}

int32 attack_backwardjump(int32 x, int32 free)
{
	return (((((x&LBJ1) >> 5)&free)&(free << 4)) | ((((x&LBJ2) >> 4)&free)&(free << 5)) | ((((x&RBJ1) >> 4)&free)&(free << 3)) | ((((x&RBJ2) >> 3)&free)&(free << 4)));
}

int32 forwardjump(int32 x, int32 free, int32 other)
{
	return ((((((x&LFJ1) << 3)&other) << 4)&free) | (((((x&LFJ2) << 4)&other) << 3)&free) | (((((x&RFJ1) << 4)&other) << 5)&free) | (((((x&RFJ2) << 5)&other) << 4)&free));
}

int32 backwardjump(int32 x, int32 free, int32 other)
{
	return ((((((x&LBJ1) >> 5)&other) >> 4)&free) | (((((x&LBJ2) >> 4)&other) >> 5)&free) | (((((x&RBJ1) >> 4)&other) >> 3)&free) | (((((x&RBJ2) >> 3)&other) >> 4)&free));
}



int countmaterial(POSITION *p, MATERIALCOUNT *m)
{
	m->bm = bitcount(p->bm);
	m->bk = bitcount(p->bk);
	m->wm = bitcount(p->wm);
	m->wk = bitcount(p->wk);
	return 0;
}



// table-lookup bitcount - newer CPUs are going to have a popcount instruction soon, would be
// much more efficient.
int bitcount(int32 n)
// returns the number of bits set in the 32-bit integer n 
{
	return __popcnt(n);
}



int PositiontoFEN(POSITION* p, char* FEN) {
	// W:WK7,11,14,18,22:B1,12,13,19,K30

	static int bit_to_square[32] = { 4,3,2,1,8,7,6,5,
		12,11,10,9,16,15,14,13,
		20,19,18,17,24,23,22,21,
		28,27,26,25,32,31,30,29 }; /* maps bits to checkers notation */


	//int i; 
	int32 tmp; 
	int square; 
	char s[16]; 
	int haskings = 0; 

	if (p->color == BLACK)
		sprintf(FEN, "B:");
	else
		sprintf(FEN, "W:"); 

	sprintf(s, "W");
	strcat(FEN, s); 
	tmp = p->wk;
	while (tmp) {
		square = LSB(tmp); 
		tmp ^= (1 << square);
		square = bit_to_square[square];
		sprintf(s, "K%i", square);
		strcat(FEN, s);
		if (tmp)
			strcat(FEN, ","); 
	}
	tmp = p->wm;
	if (p->wk)
		haskings = 1;
	else
		haskings = 0; 
	while (tmp) {
		square = LSB(tmp);
		tmp ^= (1 << square);
		square = bit_to_square[square];
		if (haskings)
			sprintf(s, ",%i", square); 
		else
			sprintf(s, "%i", square);
		strcat(FEN, s);
		if (tmp)
			strcat(FEN, ",");
		haskings = 0; 
	}

	sprintf(s, ":B");
	strcat(FEN, s);
	tmp = p->bk;
	if (p->bk)
		haskings = 1;
	else
		haskings = 0; 
	while (tmp) {
		square = LSB(tmp);
		tmp ^= (1 << square);
		square = bit_to_square[square];
		sprintf(s, "K%i", square);
		strcat(FEN, s);
		if (tmp)
			strcat(FEN, ",");
	}
	tmp = p->bm;
	while (tmp) {
		square = LSB(tmp);
		tmp ^= (1 << square);
		square = bit_to_square[square];
		if(haskings)
			sprintf(s, ",%i", square);
		else
			sprintf(s, "%i", square);
		strcat(FEN, s);
		if (tmp)
			strcat(FEN, ",");
		haskings = 0; 
	}
	strcat(FEN, "\n"); 
	return 0; 
}

int getindex(POSITION* p) {
	return index_get(p);
}

int getreverseindex(POSITION* p) {
	return index_reverse_get(p);
}

int getindex_br(POSITION* p) {
	// return the 3-rank dual color index for a position
	// now, for a given board with bm, wm, wk, I will calculate

	return (p->bm & 0xFFF);
}

int getreverseindex_br(POSITION* p) {
	// return the 3-rank dual color index for a given board - for the white side
	return (reverse12(p->wm >> 20));
}



/*Kingsrow(x64) 1.17d played 25 - 21
analysis: value = 4, depth 22 / 21.5 / 41, 2.7s, 5497 kN / s, pv 25 - 21 9 - 14 29 - 25 11 - 15 23 - 18 14x23 27x11 8x15 17 - 14 10x17 21x14
Cake 1.85_2017d(x64) played 9 - 14
analysis : depth 19 / 40 / 20.6  time 1.38s  value = 10  nodes 5452751  3922kN / s  db 98 % cut 95.3% pv  9 - 14 22 - 18 13x22 26x17 11 - 15 18x11  8x15 29 - 25
Kingsrow(x64) 1.17d played 21x14
analysis : value = 2, depth 5 / 6.7 / 12, 0.0s, 13 kN / s, pv 21x14 4 - 8 24 - 19 15x24 28x19 8 - 11
Cake 1.85_2017d(x64) played 12 - 16
analysis : depth 19 / 34 / 19.3  time 2.70s  value = 2  nodes 9382738  3460kN / s  db 100 % cut 95.6% pv 12 - 16 32 - 27 16 - 20 24 - 19 15x24 28x19  4 - 8 25 - 21
*/
/*
int analyze_matchlog(void) {
	// read match log file
	FILE* fp;
	char line[256];
	int value, d1, d2;
	double time, d3;
	double timesum_kr = 0, timesum_cake = 0;
	int n_kr = 0, n_cake = 0;
	double time_cake[100000];
	double time_kingsrow[100000];

	fp = fopen("C:\\Users\\Martin Fierz\\Documents\\Martin Fierz\\CheckerBoard\\games\\matches\\matchlog84.txt", "r");
	while (!feof(fp)) {
		fgets(line, 255, fp);
		if (line[0] == 'a' && (line[10] == 'v' || line[33] == 'v')) {  // kingsrow
			//printf("\n%s", line);
			sscanf(line, "analysis: value=%i, depth  %i/%lf/%i, %lfs", &value, &d1, &d3, &d2, &time);
			//sscanf(line, "analysis: time remaining:%fs   value=%i, depth  %i/%f/%i, %fs", &dummy, &value, &d1, &d3, &d2, &time);
			if (d1 > 10 && d1 < 50
				) {
				timesum_kr += time;
				time_kingsrow[n_kr] = time;
				n_kr++;
			}
			//printf("\n%i   %i/%.1f/%i   %.1f", value, d1, d3, d2, time);
		}
		if (line[0] == 'a' && (line[10] == 'd' || line[33] == 'd')) {  // cake
			//printf("\n%s", line);
			sscanf(line, "analysis: depth %i/%i/%lf  time %lf", &d1, &d2, &d3, &time);
			//sscanf(line, "analysis: time remaining:%fs  depth %i/%i/%f  time %f", &dummy, &d1, &d2, &d3, &time);
			//printf("\n%i/%i/%.1f %.2f", d1,d2,d3,time);
			if (d1 > 10 && d1 < 50) {
				timesum_cake += time;
				time_cake[n_cake] = time;
				n_cake++;
			}
			//getch();
		}
	}
	fclose(fp);
	printf("\nfound %i moves of kr, %i moves of cake", n_kr, n_cake);
	printf("\n\naverage time kingsrow: %.3f", timesum_kr / n_kr);
	printf("\naverage time cake: %.3f", timesum_cake / n_cake);

	// write data to file
	fp = fopen("C:\\code\\checkersdata\\time_cake.txt", "w");
	for (int i = 0; i < n_cake; i++)
		fprintf(fp, "%.3f\n", time_cake[i]);
	fclose(fp);
	fp = fopen("C:\\code\\checkersdata\\time_kingsrow.txt", "w");
	for (int i = 0; i < n_cake; i++)
		fprintf(fp, "%.3f\n", time_kingsrow[i]);
	fclose(fp);

	getch();
	exit(0);
	return 0;
}
*/


/*
int analyze_matchprogress(void) {
	// read match progress file
	FILE* fp;

	int i;
	int ballot;
	char res1, res2;
	int n[2401];
	int wins[2401];
	char filename[128];


#define NUMFILES 37

	char files[NUMFILES][128] = { "match_progress61.txt",
							"match_progress60.txt",
							"match_progress14.txt",
							"match_progress13.txt",
							"match_progress17.txt",
							"match_progress26.txt",
							"match_progress22.txt",
							"match_progress12.txt",
							"match_progress35.txt",
							"match_progress59.txt",
"match_progress6.txt",
"match_progress53.txt",
"match_progress21.txt",
"match_progress34.txt",
"match_progress25.txt",
"match_progress37.txt",
"match_progress46.txt",
"match_progress50.txt",
"match_progress58.txt",
"match_progress41.txt",
"match_progress49.txt",
"match_progress18.txt",
"match_progress27.txt",
"match_progress54.txt",
"match_progress52.txt",
"match_progress56.txt",
"match_progress43.txt",
"match_progress66.txt",
"match_progress67.txt",
"match_progress70.txt",
"match_progress75.txt",
"match_progress83.txt",
"match_progress73.txt",
"match_progress69.txt",
"match_progress84.txt",
"match_progress82.txt",
"match_progress79.txt"
	};
	char directory[128] = "C:\\Users\\Martin Fierz\\Documents\\Martin Fierz\\CheckerBoard\\games\\matches\\";


	for (i = 0; i < 2400; i++) {
		n[i] = 0;
		wins[i] = 0;
	}

	for (i = 0; i < NUMFILES; i++) {
		sprintf(filename, "%s%s", directory, files[i]);
		printf("\nanalyzing %s", filename);
		fp = fopen(filename, "r");
		if (fp == NULL) {
			printf("\nfile not found %s", filename);
		}
		while (!feof(fp)) {
			fscanf(fp, "%i:%c%c", &ballot, &res1, &res2);
			//printf("\nballot %i result %c%c", ballot, res1, res2);
			n[ballot] += 2;
			if (res1 == '+' || res1 == '-')
				wins[ballot]++;
			if (res2 == '+' || res2 == '-')
				wins[ballot]++;
		}
	}
	fclose(fp);
	//printf("\nfound %i moves of kr, %i moves of cake", n_kr, n_cake);
	//printf("\n\naverage time kingsrow: %.3f", timesum_kr / n_kr);
	//printf("\naverage time cake: %.3f", timesum_cake / n_cake);

	// write data to file
	fp = fopen("C:\\code\\checkersdata\\ballot_difficulty.txt", "w");
	for (int i = 1; i <= 2400; i++)
		fprintf(fp, "%i\t%.3f\n", i, (double)wins[i]/(double)(n[i]));
	fclose(fp);


	getch();
	exit(0);
	return 0;
} */



/*
int FENtoPosition(char* FEN, POSITION* p)
{
	// parses the FEN string in *FEN and places the result in p and color
	// example FEN string:
	// W:W32,31,30,29,28,27,26,25,24,22,21:B23,12,11,10,8,7,6,5,4,3,2,1.
	// returns 1 on success, 0 on failure.
	char* token;
	char* col, * white, * black;
	char FENstring[256];
	int i;
	int number;
	int32 one = 1;
	int piece;
	int length;
	char colorchar = 'x';


	// find the full stop in the FEN string which terminates it and
	// replace it with a 0 for termination
	length = (int)strlen(FEN);
	token = FEN;
	i = 0;
	while (token[i] != '.' && i < length)
		i++;
	token[i] = 0;

	sprintf(FENstring, "%s", FEN);

	// detect empty FEN string
	if (strcmp(FENstring, "") == 0)
		return 0;

	// parse color ,whitestring, blackstring
	col = strtok(FENstring, ":");

	if (col == NULL)
		return 0;

	if (strcmp(col, "W") == 0)
		p->color = WHITE;
	else
		p->color = BLACK;

	// parse position: get white and black strings

	white = strtok(NULL, ":");
	if (white == NULL)
		return 0;

	// check whether this was a normal fen string (white first, then black) or vice versa.
	colorchar = white[0];
	if (colorchar == 'B' || colorchar == 'b')
	{
		black = white;
		white = strtok(NULL, ":");
		if (white == NULL)
			return 0;
		// reversed fen string
	}
	else
	{
		black = strtok(NULL, ":");
		if (black == NULL)
			return 0;
	}
	// example FEN string:
	// W:W32,31,30,29,28,27,26,25,24,22,21:B23,12,11,10,8,7,6,5,4,3,2,1.
	// skip the W and B characters.
	white++;
	black++;


	// reset board
	p->bm = 0;
	p->wm = 0;
	p->bk = 0;
	p->wk = 0;

	// parse white string
	token = strtok(white, ",");

	while (token != NULL)
	{
		// While there are tokens in "string"
		// a token might be 18, or 18K
		piece = MAN;
		if (token[0] == 'K')
		{
			token++;
			piece = KING;
		}
		number = atoi(token);
		// ok, piece and number found, transform number to coors
		number = SquareToBit(number);

		if (piece == MAN)
			p->wm |= one << number;
		else
			p->wk |= one << number;
		// Get next token:
		token = strtok(NULL, ",");
	}
	// parse black string
	token = strtok(black, ",");
	while (token != NULL)
	{
		// While there are tokens in "string"
		// a token might be 18, or 18K
		piece = MAN;
		if (token[0] == 'K')
		{
			piece = KING;
			token++;
		}
		number = atoi(token);
		// ok, piece and number found, transform number to coors
		number = SquareToBit(number);
		if (piece == MAN)
			p->bm |= one << number;
		else
			p->bk |= one << number;
		// Get next token:
		token = strtok(NULL, ",");
	}
	return 1;
}*/


/*
int loadpatterns(double *weights) {
	FILE *fp = fopen("C:\\code\\checkersdata\\patternoutput.txt", "r");
	int i, weight;
	while (!feof(fp)) {
		fscanf(fp, "w[%i] = %i;\n", &i, &weight);
		printf("\n%i %i", i, weight);
		weights[i] = weight;
	}
	printf("\n\nfile read, hit key to continue");
	getch();
}*/

/*int create_indices() {
	int mult[12];

	int totalindex;
	// create multipliers for bits (12 squares, with base 3)
	mult[0] = 1;
	for (int i = 1; i < 12; i++)
		mult[i] = mult[i - 1] * 3;


	// create index for a 12-bit pattern
	for (int i = 0; i < 4096; i++) {
		index[i] = 0;
		for (int j = 0; j < 12; j++) {
			if (i & (1 << j))
				index[i] += mult[j];
		}
	}


	for (int i = 0; i < MAXINDEX; i++) {
		// i is a number between 0 and 3^12, describing the pattern of the last 3 ranks 
		// for the case that there is no opponent king on the 2nd or 3rd rank
		indexnum[i] = 0;
	}
	return 1;
}*/



/*
int getindex(POSITION* p) {
	// return the 3-rank dual color index for a position
	// now, for a given board with bm, wm, wk, I will calculate
	if ((p->wk & 0xFF0) || (p->bk & 0xFFF))
		return -1;
	return (index[p->bm & 0xFFF] + 2 * index[(p->wm & 0xFF0) + (p->wk & 0xF)]);
}

int getreverseindex(POSITION* p) {
	// return the 3-rank dual color index for a given board - for the white side
	if ((p->bk & 0xFF00000) || (p->wk & 0xFFF00000))
		return -1;
	return (index[reverse12(p->wm >> 20)] + 2 * index[reverse12(((p->bm & 0xFF00000) + (p->bk & 0xF0000000)) >> 20)]);
}
*/






