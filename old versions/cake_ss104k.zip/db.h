/*		cake++ 1.22 - a checkers engine			*/
/*															*/
/*		Copyright (C) 2001 by Martin Fierz		*/
/*															*/
/*		contact: checkers@fierz.ch					*/

/* db.h: function prototypes for cake_db.c */


long CheckPos(void);
long DBLookup(struct pos *p, int turn);
void Setup(void);
void SkipLine(void);
int DBInit(void); /* modified MF returns the number of stones it still has */
long Nsq();
int32 dbLocbvToSubIdx();
