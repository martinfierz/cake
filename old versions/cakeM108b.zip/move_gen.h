/* movegen.h: function prototypes of movegen.c */

int makemovelist(POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES],int color, int bestindex, int32 killer);
static void blackorderevaluation(POSITION *p,MOVE ml[MAXMOVES],int values[MAXMOVES],int n);
static void whiteorderevaluation(POSITION *p,MOVE ml[MAXMOVES],int values[MAXMOVES],int n);

// qs
#ifdef QSEARCH
int makeQSmovelist(POSITION *p, MOVE movelist[MAXMOVES],int color);
#endif

/* captgen.h: function prototypes for captgen.c */

int makecapturelist(POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES],int color, int32 bestindex);

static void blackmancapture1( POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void blackkingcapture1(POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void whitemancapture1( POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void whitekingcapture1(POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void blackmancapture2( POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void blackkingcapture2(POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void whitemancapture2( POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
static void whitekingcapture2(POSITION *p,MOVE movelist[MAXMOVES],int values[MAXMOVES], int *n, MOVE *partial, int32 square);
