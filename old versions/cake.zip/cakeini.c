//
//
// cakeini.c
//
//
/* contains initialization routines for cake++	*/
/* separated from the main code, in the hope	*/
/* that this will help execution speed			*/