/*		cake++ 1.35 - a checkers engine			*/
/*															*/
/*		Copyright (C) 2001 by Martin Fierz		*/
/*															*/
/*		contact: checkers@fierz.ch					*/

/* switches.h: definitions which influence the way cake++ searches */

#define VERSION "1.423"

#undef PROTECT

#include "consts.h"



//#define BOOKGEN

/* compile options for cake++*/
//#define WINMEM

#define COARSEGRAINING      		/* use evaluation coarse graining */
#define IMMEDIATERETURNONFORCED  /* if defined, cake++ will not think about forced moves*/
#define BOOK
#define USEEVALUATORS
#define CHECKTIME


#ifdef BOOKGEN
#undef CHECKTIME
#endif

#define USEDB					/* use the endgame database */
#define STOREEXACTDEPTH
#undef  EVALOFF              /* return 0 in eval */
#undef EVALMATERIALONLY     /* turn off all positional evaluation */
#define REPCHECK            /* check for repetitions */
/* repcheck reduces nodes/sec by 4% overall in the testcake test */
#define MOVEORDERING 		 /* turns on all move ordering */
									 /* if not set: overrules the three switches below ! */
#define MOHASH              /* use a move from hashtable or killer move */
#define MOKILLER 				/* use killer if no move from hashtable */
#define MOHISTORY           /* use history table */
#define MOSTATIC
#define MOTESTCAPT          /* a very expensive part of static move ordering */
#define GRAINSIZE 2         /* 2 with this grain size */
#define EXTENDALL				 /* if extendall is defined cake++ will extend if a capture
                               for the side not to move is possible */
                            /* extension for capture for the side to move is fix! */
#define QLEVEL 60 /*60*/

#define NEWTRUNCATION // use new, eval-based truncation?
#define MAXTRUNC 3*FRAC    // maximum truncation per ply 
#define TRUNCLEVEL 80        // TRUNCLEVEL was 30 for 1.42
#define TRUNCDIV 16			// divider to get ply: if outside window by 80, divide by 16 to get the number of ply to truncate

#define DOEXTENSIONS        /* use the truncation */
#define TRUNCATIONDEPTH 3*FRAC/2 //3*FRAC/2  /* how much do i truncate... */
                            /* this will be AUTOMATICALLY overruled in endgames */
                            /* where truncationdepth is set to 0! */

#define TRUNCATEVALUE 100   /* 110...if material value is more than this out of window */

//#define TRUNCATIONTEST      /* use full eval to test truncation condition */
#define TRUNCATETESTVALUE 50 /* use this value as window extension for full test */
							/* if full eval is within this value of alpha-beta, the line will not be truncated*/


#define ETC						/* use enhanced transposition cutoffs */
#define ETCDEPTH FRAC*2			/* if depth>etcdepth do ETC */

/*#define PVS  use principal variation search */
#define CHECKCAPTURESINLINE
/* some stuff for search */
#define MAXDEPTH 99				/* maximal number of plies cake++ can search */
#define FINEEVALWINDOW 300		/* if materialeval is more than this outside of alpha-beta window, do only materialeval */
#define HISTORYOFFSET 10		
#define ASPIRATIONWINDOW 10	/* aspiration window size for windowed search */
#define SINGLEEXTEND FRAC/2	/* extension for forced move */

/* hashtable settings */

#define HASHSIZE 0x00100000 // 8 MB default hashtable size

#define HASHITER 2 // 2 probes in the hashtable

#define ALWAYSSTORE     /* overwrite hashentries even if the new one has less depth? if yes, define this*/  

/* book settings, also for book builder */
#define TMPBOOKSIZE (1048576L<<1) //524288		/* size of the temporary book */
#define HASHSIZEBOOK 400000 //(131072)	/* size of the final book */
#define BUCKETSIZEBOOK 64		/* bucket size of book hashtable */
#define BOOKMINDEPTH 0			/* minimal depth which a book move must have for cake++ to use it  */

#define NEMESISTIMELIMIT


#define MTD
//#define GETLONGEST
#undef PV
//#define TESTPERF
