//
//
// cakemain.c
//
//
/* contains calling routines for cake++			*/
/* separated from the main code, in the hope	*/
/* that this will help execution speed			*/

#include "switches.h"
#include <stdio.h>
#include <stdlib.h> /* malloc() */
#include <string.h> /* memset() */
#include <time.h>

#if SYSTEM == SYS_WINDOWS
#include <conio.h>
#include <windows.h>
#endif/*SYSTEM*/

/* structs.h defines the data structures for cake++ */
#include "structs.h"

/* consts.h defines constants used by cake++ */
#include "consts.h"

/* function prototypes */
#include "cakepp.h"
#include "move_gen.h"
#include "db.h"

int cakeisinit=0;
/* a file pointer for logging */
FILE *cake_fp;

extern int Gtruncationdepth;
extern struct pos *deep, *shallow;
extern int hashsizeshallow,hashsizedeep;
extern int cake_nodes;
extern int dblookups,realdepth,maxdepth, hashstores,norefresh;
#ifdef REPCHECK
extern struct pos Ghistory[MAXDEPTH+HISTORYOFFSET+10]; /*holds the current variation for repetition check*/
#endif
extern int usethebook;
extern unsigned int leafs, leafdepth;
extern int32 Gkey,Glock;
int logging;

int cake_getmove(struct pos *position,int color, int how,double maximaltime,
					  int depthtosearch, int32 maxnodes,
					  char str[255], int *playnow, int log, int reset)
	{

	/*----------------------------------------------------------------------------*/
	/*
	/*		cake_getmove is the entry point to cake++
	/*		give a pointer to a position and you get the new position in
	/*		this structure after cake++ has calculated.
	/*		color is BLACK or WHITE and is the side to move.
	/*		how is TIME_BASED for time-based search and DEPTH_BASED for depth-based search and 
	/*		NODE_BASED for node-based search
	/*		maxtime and depthtosearch and maxnodes are used for these three search modes.
	/*		cake++ prints information in str
	/*		if playnow is set to a value != 0 cake++ aborts the search.
	/*		if (logging&1) cake++ will write information into "log.txt"
	/*		if(logging&2) cake++ will also print the information to stdout.
	/*		if reset!=0 cake++ will reset hashtables and repetition checklist
	/*----------------------------------------------------------------------------*/

	int d;
	int value=0,lastvalue=0,n,i,j, guess;
	struct move best,last, movelist[MAXMOVES];
	struct pos dummy;
	char Lstr[256];
	char tempstr[255];
	int bookvaluetype,bookfound=1,bookbestvalue;
	struct move bookmove;
	int bookequals=0;
	int bookdepth=0;
	int bookindex=-1,booklookupvalue;
	int values[MAXMOVES];
	static char *out;
	extern int *play;
	
	extern double start,maxtime; /* time variables */
	double t;
	extern int searchmode;
	extern struct pos p;
	extern int bm,bk,wm,wk;
	extern int32 history[32][32];

	play=playnow;
	out=str;
	logging=log;
	maxtime=maximaltime;
	searchmode=how;

	if(!cakeisinit) initcake(logging);

	p=(*position);
	if(logging & 1)
		{
		cake_fp=fopen("cakelog.txt","a");
		printboardtofile(p);
		fprintf(cake_fp,"\nposition hex bm bk wm wk color:\n{0x%8.8x, 0x%8.8x, 0x%8.8x, 0x%8.8x, %i}",p.bm,p.bk,p.wm,p.wk,color);
		}

	/* initialize material */
	countmaterial(&p,&bm,&bk,&wm,&wk);
#ifdef MOHISTORY
	/* reset history table */
	for(i=0;i<32;i++)
		{
		for(j=0;j<32;j++)
			{
			history[i][j]=0;
			}
		}
#endif

#ifdef PV
/* clear PV array */
	for(i=0;i<MAXDEPTH;i++)
		{
		for(j=0;j<maxdepth;j++)
			pv[i][j]=-1;
		}
#endif

	/* set truncation depth setting:
		in endgames do not truncate any more */
	if(bm+bk+wm+wk<=6) Gtruncationdepth=0;
	else Gtruncationdepth=TRUNCATIONDEPTH;

	/* clear the hashtable */
	memset(deep,0,HASHSIZEDEEP*sizeof(struct hashentry));
	memset(shallow,0,hashsizeshallow*sizeof(struct hashentry));

	/* reset all counters,
		nodes, database lookups etc */
	cake_nodes=0;
	dblookups=0;
	realdepth=0;
	maxdepth=0;
	hashstores=0;
	
#ifdef ROOTCHECK
	rootnodes=0;
#endif

	n=makecapturelist(&p,movelist,values, color, 0);

#ifdef REPCHECK
	/*initialize history list */
	Ghistory[HISTORYOFFSET]=p;
	dummy.bm=BIT0;
	dummy.wm=BIT0;
	dummy.bk=BIT0;
	dummy.wk=BIT0;
	if(reset==0)
		{
		for(i=0;i<HISTORYOFFSET-2;i++)
			Ghistory[i]=Ghistory[i+2];
		}
	else
		{
		for(i=0;i<HISTORYOFFSET+8;i++)
			Ghistory[i]=dummy;
		}
#endif

#ifdef TESTPERF
	for(i=0;i<MAXMOVES;i++)
		cutoffsat[i]=0;
#endif
	
	/* initialize hash key */
	absolutehashkey(&p);

		/* do a book lookup */
//#ifdef BOOK	
	if(usethebook)
		{
		bookfound=0;
		bookindex=0;
		
		if(booklookup(&booklookupvalue,&bookvaluetype,0,&bookdepth,color,&bookindex))
			{
			
			bookfound=1;
			
			/* this position is there, now, do all moves and look up their values */
			/* possibly, this position does not have all followups, so it is not sure
				that we really have it!*/
			n=makecapturelist(&p,movelist,values,color,0);
			if(!n)
				n=makemovelist(&p,movelist,values,color,0,0);
			/* set best value*/
						
			bookmove = movelist[bookindex];
			

			}
		/* if the remaining depth is too small, we dont use the book move */
		if(bookdepth<BOOKMINDEPTH) bookfound =0;
		if(bookfound)
			{
			movetonotation(p,bookmove,Lstr,color);
			sprintf(str,"found position in book, value=%i, move is %s (depth %i)\n",bookbestvalue,Lstr,bookdepth);
			best=bookmove;
			value=0;
			}
		else
			{
			sprintf(str,"%X %X not found in book\n",Gkey,Glock);
			value=0;
			}
		if(logging&1)
			{
			fprintf(cake_fp,"\n%s",str);
			}
		}
	else
		bookfound=0;


	absolutehashkey(&p);
	countmaterial(&p,&bm,&bk,&wm,&wk);
	n=makecapturelist(&p,movelist, values,color, 0);

	start=clock();
	guess=0;
	if(!bookfound)
		{
		for(d=1;d<MAXDEPTH;d+=2)
			{
			leafs=0;
			leafdepth=0;
	
			/* choose which search algorithm to use: */
		
			/* non - windowed search */
			/*value=firstnegamax(FRAC*d, color, -MATE, MATE, &best);*/
	
			/*******************/
			/* windowed search */
			/* standard!       */
			/*******************/
#ifndef MTD
			value=windowsearch(FRAC*d, color, guess, &best);
			// set value for next search 
			guess=value;	
#endif
#ifdef MTD
			/* MTD(F) search */
			value=mtdf(guess,FRAC*d,color,&best);
			guess=value;	
#endif
			/* generate output */
			movetonotation(p,best,Lstr,color);
			t=clock();

#ifdef ROOTCHECK
			if((t-start)>0)
				sprintf(str,"best: %s depth %i/%i/%2.1f nodes %lu (%iR) value %i time %3.2fs %4.0fkN/s",Lstr,d,maxdepth,(float)leafdepth/((float)leafs+0.01),cake_nodes,rootnodes,value,(t-start)/CLK_TCK,cake_nodes/1000/(t-start)*CLK_TCK);
			else
				sprintf(str,"best: %s depth %i/%i/%2.1f nodes %lu (%iR) value %i time %3.2fs ?kN/s",Lstr,d,maxdepth,(float)leafdepth/((float)leafs+0.01),cake_nodes,rootnodes,value,(t-start)/CLK_TCK);
#else
			if((t-start)>0)
				sprintf(str,"best: %s depth %i/%i/%2.1f nodes %lu value %i time %3.2fs %4.0fkN/s",Lstr,d,maxdepth,(float)leafdepth/((float)leafs+0.01),cake_nodes,value,(t-start)/CLK_TCK,cake_nodes/1000/(t-start)*CLK_TCK);
			else
				sprintf(str,"best: %s depth %i/%i/%2.1f nodes %lu value %i time %3.2fs ?kN/s",Lstr,d,maxdepth,(float)leafdepth/((float)leafs+0.01),cake_nodes,value,(t-start)/CLK_TCK);
#endif
				
			/*getpv(Lstr,color);
			strcat(str,Lstr);*/
			if(logging&1)
				{
				fprintf(cake_fp,"\n%s",str);
				if(d>10) fflush(cake_fp);
				}
			if(logging&2)
				{
				printf("\n%s",str);
				fflush(stdout);
				}

			/*getpv(str,color);
			printf("\n%s",str);*/
			/* iterative deepening loop break conditions: depend on search mode, 'how':
				how=0: time mode;*/
			if(d>1)
				{
#ifdef NEMESISTIMELIMIT
			/* do a 1-ply deeper search if time is getting short.*/
				if( how==TIME_BASED && ((clock()-start)/CLK_TCK>(maxtime/1.2)) ) 
					d--;
				if( how==TIME_BASED && ((clock()-start)/CLK_TCK>(1.2*maxtime)) ) 
					break;
#else
				if( how==TIME_BASED && ((clock()-start)/CLK_TCK>(maxtime/2)) ) 
					break;
#endif

				if(how==DEPTH_BASED && d>=depthtosearch)
					break;
				if(how==NODE_BASED && cake_nodes>maxnodes)
					break;
#ifdef IMMEDIATERETURNONFORCED
				/* do not search if only one move is possible */
				if(n==1) /* this move was forced! */
					{
				/* set return value to 0 so no win/loss claims hamper engine matches*/
					value=0;
					break;
					}
#endif
				if(abs(value)>MATE-100) break;
				}
			if(*play)
				{
				/* stop the search. don't use the best move & value because they are rubbish */
				best=last;
				movetonotation(p,best,Lstr,color);
				value=lastvalue;
#ifndef ANALYSISMODULE
				sprintf(str,"interrupt: best %s value %i",Lstr,value);
#endif
				break;
				}
			lastvalue=value; /* save the value for this iteration */
			last=best; /* save the best move on this iteration */
			norefresh=1;
			}
		}
#ifdef REPCHECK
	Ghistory[HISTORYOFFSET-2]=p;
#endif
	if(!bookfound)
		{
		getpv(Lstr,color);
		//printf("\n%s",Lstr);
		//getrealpv(Lstr,color);
		//printf("\n%s",Lstr);
#ifndef ANALYSISMODULE
		strcat(str,"\n");
		strcat(str,Lstr);
		sprintf(tempstr,"");
		strcat(tempstr,str);
		sprintf(str,tempstr);
#endif
		}
	if(!(*play))
		{togglemove(best);}
	else
		{togglemove(last);}
	if(logging&1)
		{
		fprintf(cake_fp,"%s\n",Lstr);
		fflush(cake_fp);
		}
	if(logging&2)
		{
		printf("%s\n",Lstr);
		fflush(stdout);
		}
#ifdef REPCHECK
	Ghistory[HISTORYOFFSET-1]=p;
#endif
	*position=p;
	if(logging&1) fclose(cake_fp);
	//printf("\nsearched %i foundhash %i foundkiller %i",searched, foundhash, foundkiller);
#ifdef TESTPERF
	analyzeHT();
	TP_deepnotstored=0;
	printf("\n");
	j=0;
	for(i=0;i<MAXMOVES;i++)
		j+=cutoffsat[i];
	for(i=0;i<10;i++)
		printf("%.1f ",100*(double)cutoffsat[i]/(double)j);
#endif
	return value;
}
