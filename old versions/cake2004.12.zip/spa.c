#include "switches.h"

#include <stdio.h>
#include <stdlib.h> /* malloc() */
#include <string.h> /* memset() */
#include <windows.h>

/* structs.h defines the data structures for cake++ */
#include "structs.h"

/* consts.h defines constants used by cake++ */
#include "consts.h"

/* function prototypes */
#include "cakepp.h"

SPA_ENTRY *spatable;

int initspa(void)
	{
	int i=0,j;
	int32 lock, key;
	FILE *fp;
	SPA_POSITION spapos;
	SPA_ENTRY spaentry;
	POSITION p;
	char *buffer;
	int items;
	int index;
	int k;

	spatable = NULL;
#ifdef WINMEM
	spatable = VirtualAlloc(0, (SPASIZE+SPAITER)*sizeof(SPA_ENTRY), MEM_COMMIT, PAGE_READWRITE);
#else
	spatable=malloc((SPASIZE+SPAITER)*sizeof(SPA_ENTRY));
	memset(spatable,0,(SPASIZE+SPAITER)*sizeof(SPA_ENTRY));
#endif

	if(spatable == NULL)
		{
		printf("\ncould not allocate spa memory!");
		//getch();
		}

	fp = fopen("analysed-12pc-men.dat", "rb");
	if(fp == NULL)
		{
		printf("\ncould not allocate spa memory!");
		//getch();
		}

	// now, load spa position for spa position, transform position into a hashkey,
	// and store in spa hashtable
	printf("\nsizeof(SPA_ENTRY) is %i",sizeof(SPA_ENTRY));
	buffer = malloc(1024*sizeof(SPA_POSITION));
	while(!feof(fp) /*&& i<2*1024*1024*/)
		{
		// read
		items = fread(buffer,sizeof(SPA_POSITION),1024,fp);
		for(j=0;j<items;j++)
			{
			memcpy(&spapos, buffer+j*sizeof(SPA_POSITION), sizeof(SPA_POSITION));
			// transform to position
			p.bm = spapos.black & (~spapos.kings);
			p.bk = spapos.black & spapos.kings;
			p.wm = spapos.white & (~spapos.kings);
			p.wk = spapos.white & spapos.kings;
			// get hashkey
			position_to_hashkey(&p, &key, &lock);
			//printf("\nkey,lock: %u %u",key,lock);
			//printboard(&p,BLACK);
			//printf("\nsearch eval, static eval %i %i",spapos.value, spapos.staticeval);
			//getch();
			
			// transform to spaentry
			spaentry.hashkey = lock;
			spaentry.value = spapos.value;
			// save in spatable
			index = key & (SPASIZE-1);
			
			for(k=0;k<SPAITER;k++)
				{
				if(spatable[index+k].hashkey == 0)
					{
					spatable[index+k] = spaentry;
					}
				}
			// we don't overwrite in SPA table!
			i++;
			if(!(i%(1024*1024)))
				printf("\nreading spa: %i positions read",i);
			}
		}
	}

int spa_lookup(int32 key, int32 lock, int *eval)
	{
	int index;
	int i;
	index = key&(SPASIZE-1);

	for(i=0;i<SPAITER;i++)
		{
		if(spatable[index+i].hashkey == lock)
			{
			*eval = spatable[index+i].value;
			return 1;
			}
		}
	return 0;
	}

int position_to_hashkey(POSITION *p, int32 *key, int32 *lock)
	{
//	int32 x;
	int32 lkey = 0,llock = 0;
	extern int32 Gkey, Glock; // from cakepp.c

	absolutehashkey(p);
	//printf("\nkey, lock: %i %i",Gkey, Glock);
	*key = Gkey;
	*lock = Glock;

	return 1;
	}

