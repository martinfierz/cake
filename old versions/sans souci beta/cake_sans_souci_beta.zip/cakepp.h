/*		cake++ 1.22 - a checkers engine			*/
/*															*/
/*		Copyright (C) 2001 by Martin Fierz		*/
/*															*/
/*		contact: checkers@fierz.ch					*/

/* cake++.h */
#include "switches.h"
/* prototypes for all functions in cake++ */
int initcake(int logging, char str[1024]);
int exitcake(void);
int cake_getmove(POSITION *p,int color, int how,double maxtime, int depthtosearch,int32 maxnodes, char str[1024], int *playnow, int logging,int reset);
/* returns the value of the position */
static void countmaterial(POSITION *p);
static void initboard(void);
static int firstnegamax(POSITION *p, int d, int color, int alpha, int beta, MOVE *best);
static int negamax(POSITION *p,int depth, int color, int alpha, int beta, int32 *bestproto, int truncationdepth, int truncationdepth2);
#ifdef IITERD
static int iidnegamax(POSITION *p,int depth, int color, int alpha, int beta, int32 *bestproto, int truncationdepth, int truncationdepth2);
#endif
int evaluation(POSITION *p,int color, int alpha, int beta,int *noprune);
static int mtdf(POSITION *p, int firstguess,int depth, int color, MOVE *best);
static int windowsearch(POSITION *p, int depth, int color, int guess, MOVE *best);
static int fineevaluation(POSITION *p,int color, int *noprune);

static int bitcount(int32 n);
int recbitcount(int32 n);
int LSB(int32 x);
static void absolutehashkey(POSITION *p);
void updatehashkey(MOVE *m);
void hashstore(POSITION *p, int value, int alpha, int beta, int depth, MOVE *best, int color, int32 bestindex);
int hashlookup(int *value, int *valuetype, int depth, int32 *bestindex, int color, int *ispvnode);
int hashreallocate(int MB);
static int booklookup(int *value, int depth, int32 *best, int color, int *bestindex);
static void movetonotation(POSITION *p, MOVE *m, char *str, int color);
static void getpv(POSITION *p, char *str, int color);
int testcapture(POSITION *p,int color);
int isforced(POSITION *p,int color);
#ifdef USEDB
int dbwineval(POSITION *p,int color);
int dblosseval(POSITION *p,int color);
#endif
void printboardtofile(POSITION *p);
void printboard(POSITION *p);
#ifdef OPLIB
static void boardtobitboard(int b[8][8], POSITION *p);
#endif
static int32 myrand(void);
#ifdef ETC
int ETClookup(POSITION *p, MOVE movelist[MAXMOVES], int d, int n,int color);
#endif

#ifdef BOOKGEN
static booknegamax(POSITION *p, int color, int depth, int alpha, int beta, int values[MAXMOVES]);
bookgen(POSITION *p, int color, int *n, int values[MAXMOVES], int how, int depth, double time);
bookmtdf(POSITION *p,int firstguess,int depth,int color,MOVE *best,int bestvaluesofar);
#endif

static int32 attack_forwardjump(int32 x, int32 free);
static int32 attack_backwardjump(int32 x, int32 free);
static int32 forwardjump(int32 x, int32 free,int32 other);
static int32 backwardjump(int32 x, int32 free,int32 other);

// pattern matching macros
#define match1(a,b) ( ((a)&(b)) == (b) )
#define match2(a,b,c,d) ( (((a)&(c))|((b)&(d))) ==((c)|(d)))
#define match3(a,b,c,d,e,f) ( (((a)&(d))|((b)&(e))|((c)&(f))) ==((d)|(e)|(f)))
