/*		cake++ 1.3 - a checkers engine			*/
/*															*/
/*		Copyright (C) 2001 by Martin Fierz		*/
/*															*/
/*		contact: checkers@fierz.ch					*/

/* cake++.h */
#include "switches.h"
/* prototypes for all functions in cake++ */
int initcake(int logging);
int exitcake(void);
int cake_getmove(struct pos *position,int color, int how,double maxtime, int depthtosearch,int32 maxnodes, char str[255], int *playnow, int logging,int reset);
/* returns the value of the position */
void countmaterial(void);
void initboard(void);
int firstnegamax(int d, int color, int alpha, int beta, struct move *best);
int negamax(struct pos *p,int depth, int color, int alpha, int beta, int32 *bestproto, int truncationdepth);
int evaluation(struct pos *p,int color, int alpha, int beta);
int mtdf(int firstguess,int depth, int color, struct move *best);
int windowsearch(int depth, int color, int guess, struct move *best);

int fineevaluation(struct pos *p,int color);

int bitcount(int32 n);
int recbitcount(int32 n);
int lastbit(int32 x);
void absolutehashkey(struct pos *p);
void updatehashkey(struct move m);
void hashstore(struct pos *p, int value, int alpha, int beta, int depth, struct move best, int color, int32 bestindex);
int hashlookup(int *value, int *valuetype, int depth, int32 *bestindex, int color);
int booklookup(int *value, int *valuetype, int depth, int32 *best, int color);
void movetonotation(struct pos position,struct move m, char *str, int color);
void getpv(char *str, int color);
int testcapture(struct pos *p,int color);
#ifdef USEDB
int dbwineval(struct pos *p,int color);
int dblosseval(struct pos *p,int color);
#endif
void printboardtofile(struct pos p);
void printboard(struct pos p);
#ifdef OPLIB
void boardtobitboard(int b[8][8], struct pos *position);
#endif
int32 myrand(void);
#ifdef ETC
int ETClookup(struct move movelist[MAXMOVES], int n, int d, int color);
#endif

long DBLookup(struct pos *p, int turn);

