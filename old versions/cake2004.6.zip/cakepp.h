//		cake - a checkers engine			
//															
//		Copyright (C) 2001 -2004 by Martin Fierz		
//															
//		contact: checkers@fierz.ch					

/* cake++.h */
#include "switches.h"

/* prototypes for all functions in cake++ */
static void absolutehashkey(POSITION *p);
static int32 attack_backwardjump(int32 x, int32 free);
static int32 attack_forwardjump(int32 x, int32 free);
static int32 backwardjump(int32 x, int32 free,int32 other);
static int bitcount(int32 n);
static int booklookup(POSITION *p, int *value, int depth, int32 *best, int color, int *bestindex, char str[256]);
int cake_getmove(POSITION *p,int color, int how,double maxtime, int depthtosearch,int32 maxnodes, char str[1024], int *playnow, int logging,int reset);
static void countmaterial(POSITION *p);
int evaluation(POSITION *p,int color, int alpha, int beta,int *noprune);
int exitcake(void);
static int fineevaluation(POSITION *p,int color, int *noprune, int*likelydraw);
static int firstnegamax(POSITION *p, int d, int color, int alpha, int beta, MOVE *best);
static int32 forwardjump(int32 x, int32 free,int32 other);
static void getpv(POSITION *p, char *str, int color);
int hashlookup(int *value, int *valuetype, int depth, int32 *bestindex, int color, int *ispvnode);
int hashreallocate(int MB);
void hashstore(POSITION *p, int value, int alpha, int beta, int depth, MOVE *best, int color, int32 bestindex);
static void initboard(void);
int initcake(int logging, char str[1024]);
int isforced(POSITION *p,int color);
int LSB(int32 x);
static void movetonotation(POSITION *p, MOVE *m, char *str, int color);
static int mtdf(POSITION *p, int firstguess,int depth, int color, MOVE *best);
static int32 myrand(void);
static int negamax(POSITION *p,int depth, int color, int alpha, int beta, int32 *bestproto, int truncationdepth, int truncationdepth2);
void printboard(POSITION *p, int color);
void printboardtofile(POSITION *p);
int recbitcount(int32 n);
int selftrapeval(POSITION *p, int color, int *delta);
int testcapture(POSITION *p,int color);
void updatehashkey(MOVE *m);
static int windowsearch(POSITION *p, int depth, int color, int guess, MOVE *best);
void searchinfotostring(char *out, int depth, int maxdepth, double time, char *str1, char *str2, COUNTER *counter);


//static int oldbooklookup(int *value, int depth, int32 *best, int color, int *bestindex);

#ifdef IITERD
static int iidnegamax(POSITION *p,int depth, int color, int alpha, int beta, int32 *bestproto, int truncationdepth, int truncationdepth2);
#endif

#ifdef USEDB
int dbwineval(POSITION *p,int color);
int dblosseval(POSITION *p,int color);
#endif

#ifdef OPLIB
static void boardtobitboard(int b[8][8], POSITION *p);
#endif

#ifdef ETC
int ETClookup(POSITION *p, MOVE movelist[MAXMOVES], int d, int n,int color, int *bestindex);
#endif

#ifdef BOOKGEN
static booknegamax(POSITION *p, int color, int depth, int alpha, int beta, int values[MAXMOVES]);
bookgen(POSITION *p, int color, int *n, int values[MAXMOVES], int how, int depth, double time);
bookmtdf(POSITION *p,int firstguess,int depth,int color,MOVE *best,int bestvaluesofar);
#endif

#ifdef QSEARCH
int qsearch(POSITION *p, int color, int alpha, int beta);
#endif

#ifdef QS_SQUEEZE
int issqueeze(POSITION *p, int color);
#endif

// pattern matching macros
#define match1(a,b) ( ((a)&(b)) == (b) )
#define match2(a,b,c,d) ( (((a)&(c))|((b)&(d))) ==((c)|(d)))
#define match3(a,b,c,d,e,f) ( (((a)&(d))|((b)&(e))|((c)&(f))) ==((d)|(e)|(f)))
