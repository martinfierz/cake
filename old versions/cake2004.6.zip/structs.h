/*		cake++ - a checkers engine
 *
 *		Copyright (C) 2001 by Martin Fierz
 *
 *		contact: checkers@fierz.ch
 */
/* structs.h: data structures for cake++ */

/*definitions for platform-independence*/
#define int32 unsigned int
#define int16 unsigned short
#define int8  unsigned char
#define sint32 signed int
#define sint16 signed short
#define sint8  signed char


struct coor             /* coordinate structure for board coordinates */
	{
	int x;
	int y;
	};

struct CBmove				/* all the information you need about a move */
	{
	int ismove; 		 /* kind of superfluous: is 0 if the move is not a valid move */
	int newpiece;		/* what type of piece appears on to */
	int oldpiece;		/* what disappears on from */
	struct coor from,to; /* coordinates of the piece - in 8x8 notation!*/
	struct coor path[12]; /* intermediate path coordinates of the moving piece */
	struct coor del[12]; /* squares whose pieces are deleted after the move */
	int delpiece[12];	/* what is on these squares */
	};

typedef struct
	{
	int32 negamax;
	int32 iidnegamax;
	int32 qsearch;
	int32 leaf;
	int32 leafdepth;
	int32 cutoffs;
	int32 cutoffsatfirst;
	int32 dblookup;
	int32 dblookupsuccess;
	int32 dblookupfail;
	int32 hashlookup;
	int32 hashlookupsuccess;
	} COUNTER;

typedef struct 
	{
	int32 bm;
	int32 bk;
	int32 wm;
	int32 wk;
	} POSITION;

typedef struct 
	{
	int32 bm;
	int32 wm;
	} MANPOSITION;

typedef struct
	{
	int32 black;
	int32 white;
	int32 kings;
	unsigned int best:6;
	unsigned int color:2;
	unsigned int depth:10;
	int value:14;
	} LEARNENTRY;

typedef struct 
	{
	int32 bm;
	int32 bk;
	int32 wm;
	int32 wk;
	} MOVE;


typedef struct
// struct hashentry needs 8 bytes 
	{
	int32  lock;
	unsigned int best:6;
	int value:12;
	unsigned int color:1;
	unsigned int ispvnode:1;
	unsigned int depth:10;
	unsigned int valuetype:2;
	} HASHENTRY;

/*
// struct hashentry needs 9 bytes 
	{
	int32  lock;
	int upper:12;
	int upperdepth:10;
	int lowerdepth:10;
	// 64 bits
	int lower:12;
	unsigned int best:6;
	unsigned int color:1;
	unsigned int ispvnode:1;
	int unused:12;
	} HASHENTRY;
*/

struct bookhashentry
	// bookhashentry is the struct used for the book hashtable
	// we can store 3 moves per position.
	{
	int32  lock;

	unsigned int color:2;
	unsigned int best:6;
	int value:14;
	unsigned int depth:10;
	
	/*unsigned int best2:6; 
	unsigned int value2:4;			// value2 is the difference in value to the best value.
	unsigned int depth2:6;			// can be up to 15, and if it's worse than that, we don't have a move.
	
	unsigned int best3:6;
	unsigned int value3:4;
	unsigned int depth3:6;*/
	};

struct dbhashentry
	{
	unsigned int lock: 28;
	unsigned int color: 2;
	unsigned int result: 2;
	};

typedef struct 
	{
	struct hashentry *pointer;
	int32 size;
	int bucketsize;
	} HASHTABLE;